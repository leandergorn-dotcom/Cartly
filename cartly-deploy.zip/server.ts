import express, { Request, Response } from 'express';
import http from 'http';
import path from 'path';
import fs from 'fs';
import { WebSocketServer, WebSocket } from 'ws';
import { Household, GroceryItem, ActivityLog, Member } from './src/types';

const PORT = Number(process.env.PORT) || 3000;
const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

app.use(express.json());

// Persistent store setup
// DATA_DIR zeigt beim Hosting auf einen dauerhaften Speicher (Volume/Disk), sonst gehen Daten bei Neustarts verloren
const DATA_DIR = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.resolve('.data');
const DATA_FILE = path.join(DATA_DIR, 'store.json');

interface StoreData {
  households: Record<string, Household>;
  items: Record<string, GroceryItem[]>;
  activities: Record<string, ActivityLog[]>;
}

const defaultSeedHouseholds: Record<string, Household> = {
  'MLR-842': {
    id: 'MLR-842',
    name: 'The Miller Family',
    createdAt: Date.now() - 86400000 * 7,
    members: [
      { id: 'm-sarah', name: 'Sarah', color: '#094cb2', isOnline: true, lastActive: Date.now() },
      { id: 'm-miller', name: 'Miller', color: '#16a34a', isOnline: true, lastActive: Date.now() },
    ],
  },
  'KUK-123': {
    id: 'KUK-123',
    name: 'Familie Kuku',
    createdAt: Date.now() - 86400000 * 3,
    members: [
      { id: 'm-anna', name: 'Anna', color: '#094cb2', isOnline: true, lastActive: Date.now() },
      { id: 'm-kuku', name: 'Leo', color: '#e11d48', isOnline: true, lastActive: Date.now() },
    ],
  },
};

const defaultSeedItems: Record<string, GroceryItem[]> = {
  'MLR-842': [
    {
      id: 'item-1',
      householdId: 'MLR-842',
      name: 'Aged Gouda Cheese',
      category: 'dairy',
      quantity: '200g',
      tag: 'Sarah',
      checked: false,
      addedBy: 'Sarah',
      addedAt: Date.now() - 3600000 * 2,
    },
    {
      id: 'item-2',
      householdId: 'MLR-842',
      name: 'Oat Milk Barista Edition',
      category: 'dairy',
      quantity: '2 cartons',
      tag: 'Oatly',
      checked: false,
      addedBy: 'Miller',
      addedAt: Date.now() - 3600000 * 3,
    },
    {
      id: 'item-3',
      householdId: 'MLR-842',
      name: 'Vine Ripe Tomatoes',
      category: 'produce',
      quantity: '1 kg',
      tag: 'Organic',
      checked: false,
      addedBy: 'Sarah',
      addedAt: Date.now() - 3600000 * 4,
    },
    {
      id: 'item-4',
      householdId: 'MLR-842',
      name: 'Persian Cucumbers',
      category: 'produce',
      quantity: '500g',
      tag: 'Crisp mini',
      checked: false,
      addedBy: 'Miller',
      addedAt: Date.now() - 3600000 * 5,
    },
    {
      id: 'item-5',
      householdId: 'MLR-842',
      name: 'Yukon Gold Potatoes',
      category: 'produce',
      quantity: '2 kg bag',
      checked: false,
      addedBy: 'Sarah',
      addedAt: Date.now() - 3600000 * 6,
    },
    {
      id: 'item-6',
      householdId: 'MLR-842',
      name: 'Honeycrisp Apples',
      category: 'snacks',
      quantity: '6 pcs',
      tag: 'Sweet & crisp',
      checked: false,
      addedBy: 'Sarah',
      addedAt: Date.now() - 3600000 * 7,
    },
    {
      id: 'item-7',
      householdId: 'MLR-842',
      name: 'Plain Greek Yogurt',
      category: 'dairy',
      quantity: '4 x 150g',
      tag: '0% Fat',
      checked: false,
      addedBy: 'Miller',
      addedAt: Date.now() - 3600000 * 8,
    },
  ],
  'KUK-123': [
    {
      id: 'kuk-1',
      householdId: 'KUK-123',
      name: 'Weiteres Lebensmittel',
      category: 'produce',
      quantity: '1x',
      note: 'z. B. aus welchem Laden oder welche Marke',
      checked: false,
      addedBy: 'Anna',
      addedAt: Date.now() - 3600000,
    },
    {
      id: 'kuk-2',
      householdId: 'KUK-123',
      name: 'Beispiel-Lebensmittel',
      category: 'dairy',
      quantity: '2x',
      note: 'Hier kannst du eine kleine Notiz hinzufügen',
      checked: false,
      addedBy: 'Leo',
      addedAt: Date.now() - 3600000 * 2,
    },
    {
      id: 'kuk-3',
      householdId: 'KUK-123',
      name: 'Bereits abgehakter Eintrag',
      category: 'other',
      quantity: '1x',
      checked: true,
      checkedAt: Date.now() - 1800000,
      addedBy: 'Anna',
      addedAt: Date.now() - 3600000 * 4,
    },
    {
      id: 'kuk-4',
      householdId: 'KUK-123',
      name: 'Noch ein erledigter Einkauf',
      category: 'other',
      quantity: '3x',
      checked: true,
      checkedAt: Date.now() - 900000,
      addedBy: 'Leo',
      addedAt: Date.now() - 3600000 * 5,
    },
  ],
};

let store: StoreData = {
  households: { ...defaultSeedHouseholds },
  items: { ...defaultSeedItems },
  activities: {
    'MLR-842': [
      { id: 'act-1', householdId: 'MLR-842', type: 'add', itemName: 'Plain Greek Yogurt', memberName: 'Miller', timestamp: Date.now() - 3600000 * 8 },
      { id: 'act-2', householdId: 'MLR-842', type: 'add', itemName: 'Aged Gouda Cheese', memberName: 'Sarah', timestamp: Date.now() - 3600000 * 2 },
    ],
    'KUK-123': [
      { id: 'act-3', householdId: 'KUK-123', type: 'check', itemName: 'Bereits abgehakter Eintrag', memberName: 'Anna', timestamp: Date.now() - 1800000 },
      { id: 'act-4', householdId: 'KUK-123', type: 'check', itemName: 'Noch ein erledigter Einkauf', memberName: 'Leo', timestamp: Date.now() - 900000 },
    ],
  },
};

// Load saved data if present
try {
  if (fs.existsSync(DATA_FILE)) {
    const raw = fs.readFileSync(DATA_FILE, 'utf-8');
    const parsed = JSON.parse(raw);
    if (parsed.households) store.households = { ...store.households, ...parsed.households };
    if (parsed.items) store.items = { ...store.items, ...parsed.items };
    if (parsed.activities) store.activities = { ...store.activities, ...parsed.activities };
  }
} catch (e) {
  console.warn('Could not read existing store, using defaults.', e);
}

function saveStore() {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(DATA_FILE, JSON.stringify(store, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving store:', err);
  }
}

// Generate code like "MLR-842" or "KUK-739"
function generateCode(name?: string): string {
  let prefix = 'FAM';
  if (name) {
    const clean = name.replace(/[^a-zA-Z]/g, '').toUpperCase();
    if (clean.length >= 3) {
      prefix = clean.slice(0, 3);
    }
  }
  const num = Math.floor(100 + Math.random() * 900);
  let code = `${prefix}-${num}`;
  while (store.households[code]) {
    code = `${prefix}-${Math.floor(100 + Math.random() * 900)}`;
  }
  return code;
}

// REST Endpoints
app.get('/api/households/:id', (req: Request, res: Response) => {
  const code = (req.params.id || '').toUpperCase().trim();
  const household = store.households[code];
  if (!household) {
    return res.status(404).json({ error: 'Household not found' });
  }
  const items = store.items[code] || [];
  const activities = store.activities[code] || [];
  res.json({ household, items, activities });
});

app.post('/api/households', (req: Request, res: Response) => {
  const { name, memberName } = req.body;
  if (!name || typeof name !== 'string') {
    return res.status(400).json({ error: 'Name is required' });
  }
  const id = generateCode(name);
  const household: Household = {
    id,
    name: name.trim(),
    createdAt: Date.now(),
    members: [
      {
        id: `m-${Date.now()}`,
        name: memberName ? memberName.trim() : 'Admin',
        color: '#094cb2',
        isOnline: true,
        lastActive: Date.now(),
      },
    ],
  };

  store.households[id] = household;
  store.items[id] = [];
  store.activities[id] = [
    {
      id: `act-${Date.now()}`,
      householdId: id,
      type: 'join',
      memberName: household.members[0].name,
      timestamp: Date.now(),
    },
  ];
  saveStore();

  res.status(201).json({ household, items: [], activities: store.activities[id] });
});

app.post('/api/households/:id/join', (req: Request, res: Response) => {
  const code = (req.params.id || '').toUpperCase().trim();
  const { memberName } = req.body;
  const household = store.households[code];
  if (!household) {
    return res.status(404).json({ error: 'Household not found' });
  }

  const nicknames = [
    'Naschkatze',
    'Avocado-Fan',
    'Käseliebhaber',
    'Pasta-Chef',
    'Gourmet-Bär',
    'Müslifreund',
    'Zimtstern',
    'Snack-Held',
    'Beerenpflücker',
    'Kaffee-Guru',
  ];
  const randomNick = nicknames[Math.floor(Math.random() * nicknames.length)];
  const name = memberName && memberName.trim() ? memberName.trim() : randomNick;
  let existingMember = household.members.find((m) => m.name.toLowerCase() === name.toLowerCase());
  if (!existingMember) {
    existingMember = {
      id: `m-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      name,
      color: ['#094cb2', '#16a34a', '#d97706', '#9333ea', '#e11d48'][household.members.length % 5],
      isOnline: true,
      lastActive: Date.now(),
    };
    household.members.push(existingMember);
    const activity: ActivityLog = {
      id: `act-${Date.now()}`,
      householdId: code,
      type: 'join',
      memberName: name,
      timestamp: Date.now(),
    };
    if (!store.activities[code]) store.activities[code] = [];
    store.activities[code].unshift(activity);
    saveStore();
    broadcastToHousehold(code, { type: 'presence_updated', members: household.members, activity });
  }

  res.json({ household, items: store.items[code] || [], activities: store.activities[code] || [], member: existingMember });
});

app.post('/api/households/:id/items', (req: Request, res: Response) => {
  const code = (req.params.id || '').toUpperCase().trim();
  const household = store.households[code];
  if (!household) {
    return res.status(404).json({ error: 'Household not found' });
  }

  const { name, category, quantity, note, tag, addedBy } = req.body;
  if (!name || typeof name !== 'string') {
    return res.status(400).json({ error: 'Item name is required' });
  }

  const newItem: GroceryItem = {
    id: `item-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    householdId: code,
    name: name.trim(),
    category: category || 'other',
    quantity: (quantity || '1x').trim(),
    note: note ? note.trim() : undefined,
    tag: tag ? tag.trim() : undefined,
    checked: false,
    addedBy: addedBy || 'Familie',
    addedAt: Date.now(),
  };

  if (!store.items[code]) store.items[code] = [];
  store.items[code].unshift(newItem);

  const activity: ActivityLog = {
    id: `act-${Date.now()}`,
    householdId: code,
    type: 'add',
    itemName: newItem.name,
    memberName: newItem.addedBy,
    timestamp: Date.now(),
  };
  if (!store.activities[code]) store.activities[code] = [];
  store.activities[code].unshift(activity);

  saveStore();
  broadcastToHousehold(code, { type: 'item_added', item: newItem, activity });

  res.status(201).json({ item: newItem, activity });
});

app.patch('/api/households/:id/items/:itemId', (req: Request, res: Response) => {
  const code = (req.params.id || '').toUpperCase().trim();
  const itemId = req.params.itemId;
  const items = store.items[code];
  if (!items) {
    return res.status(404).json({ error: 'Household items not found' });
  }

  const item = items.find((i) => i.id === itemId);
  if (!item) {
    return res.status(404).json({ error: 'Item not found' });
  }

  const { checked, quantity, note, tag, name, memberName } = req.body;
  let activityType: ActivityLog['type'] | null = null;

  if (typeof checked === 'boolean' && checked !== item.checked) {
    item.checked = checked;
    item.checkedAt = checked ? Date.now() : undefined;
    activityType = checked ? 'check' : 'uncheck';
  }

  if (typeof quantity === 'string') item.quantity = quantity;
  if (typeof note === 'string') item.note = note;
  if (typeof tag === 'string') item.tag = tag;
  if (typeof name === 'string') item.name = name;

  let activity: ActivityLog | undefined;
  if (activityType) {
    activity = {
      id: `act-${Date.now()}`,
      householdId: code,
      type: activityType,
      itemName: item.name,
      memberName: memberName || item.addedBy,
      timestamp: Date.now(),
    };
    if (!store.activities[code]) store.activities[code] = [];
    store.activities[code].unshift(activity);
  }

  saveStore();
  broadcastToHousehold(code, { type: 'item_updated', item, activity });

  res.json({ item, activity });
});

app.delete('/api/households/:id/items/:itemId', (req: Request, res: Response) => {
  const code = (req.params.id || '').toUpperCase().trim();
  const itemId = req.params.itemId;
  const items = store.items[code];
  if (!items) {
    return res.status(404).json({ error: 'Household items not found' });
  }

  const index = items.findIndex((i) => i.id === itemId);
  if (index === -1) {
    return res.status(404).json({ error: 'Item not found' });
  }

  const removed = items.splice(index, 1)[0];
  const memberName = req.query.memberName as string || 'Familie';

  const activity: ActivityLog = {
    id: `act-${Date.now()}`,
    householdId: code,
    type: 'delete',
    itemName: removed.name,
    memberName,
    timestamp: Date.now(),
  };
  if (!store.activities[code]) store.activities[code] = [];
  store.activities[code].unshift(activity);

  saveStore();
  broadcastToHousehold(code, { type: 'item_deleted', itemId, activity });

  res.json({ success: true, itemId });
});

// Reset / Uncheck all items for a new grocery run
app.post('/api/households/:id/reset-shopping', (req: Request, res: Response) => {
  const code = (req.params.id || '').toUpperCase().trim();
  const items = store.items[code] || [];
  items.forEach((item) => {
    item.checked = false;
    delete item.checkedAt;
  });
  saveStore();
  broadcastToHousehold(code, { type: 'shopping_reset', items });
  res.json({ success: true, items });
});

// Clear checked items completely
app.post('/api/households/:id/clear-completed', (req: Request, res: Response) => {
  const code = (req.params.id || '').toUpperCase().trim();
  if (store.items[code]) {
    store.items[code] = store.items[code].filter((i) => !i.checked);
  }
  saveStore();
  broadcastToHousehold(code, { type: 'items_cleared', items: store.items[code] });
  res.json({ success: true, items: store.items[code] });
});

// WebSocket Room Management
interface ClientMeta {
  ws: WebSocket;
  householdId?: string;
  member?: Member;
}

const clients = new Map<WebSocket, ClientMeta>();

function broadcastToHousehold(householdId: string, payload: any, senderWs?: WebSocket) {
  const msg = JSON.stringify(payload);
  for (const [ws, meta] of clients.entries()) {
    if (meta.householdId === householdId && ws.readyState === WebSocket.OPEN) {
      if (ws !== senderWs || payload.echoBack) {
        ws.send(msg);
      }
    }
  }
}

// Herzschlag: hält Verbindungen hinter Proxys offen und räumt tote Handys-Verbindungen ab
const heartbeat = setInterval(() => {
  wss.clients.forEach((c: any) => {
    if (c.isAlive === false) return c.terminate();
    c.isAlive = false;
    c.ping();
  });
}, 25000);
wss.on('close', () => clearInterval(heartbeat));

app.get('/healthz', (_req: Request, res: Response) => { res.json({ ok: true }); });

wss.on('connection', (ws: WebSocket) => {
  (ws as any).isAlive = true;
  ws.on('pong', () => { (ws as any).isAlive = true; });
  const clientMeta: ClientMeta = { ws };
  clients.set(ws, clientMeta);

  ws.on('message', (messageData: string) => {
    try {
      const data = JSON.parse(messageData.toString());

      if (data.type === 'subscribe') {
        const householdId = (data.householdId || '').toUpperCase().trim();
        clientMeta.householdId = householdId;
        clientMeta.member = data.member;

        const household = store.households[householdId];
        if (household && clientMeta.member) {
          const m = household.members.find((mem) => mem.name === clientMeta.member?.name);
          if (m) {
            m.isOnline = true;
            m.lastActive = Date.now();
          }
        }

        // Send current state
        ws.send(
          JSON.stringify({
            type: 'init_sync',
            household: store.households[householdId],
            items: store.items[householdId] || [],
            activities: store.activities[householdId] || [],
          })
        );

        broadcastToHousehold(householdId, {
          type: 'presence_updated',
          members: household ? household.members : [],
        });
      } else if (data.type === 'typing') {
        if (clientMeta.householdId) {
          broadcastToHousehold(
            clientMeta.householdId,
            {
              type: 'member_typing',
              memberName: data.memberName,
              status: data.status,
            },
            ws
          );
        }
      }
    } catch (e) {
      console.error('WS message error:', e);
    }
  });

  ws.on('close', () => {
    if (clientMeta.householdId && clientMeta.member) {
      const hh = store.households[clientMeta.householdId];
      if (hh) {
        const mem = hh.members.find((m) => m.name === clientMeta.member?.name);
        if (mem) {
          mem.isOnline = false;
          mem.lastActive = Date.now();
          broadcastToHousehold(clientMeta.householdId, {
            type: 'presence_updated',
            members: hh.members,
          });
        }
      }
    }
    clients.delete(ws);
  });
});

// Vite middleware in dev or static files in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve('dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve('dist', 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Cartly fullstack server running on http://localhost:${PORT}`);
  });
}

startServer();
