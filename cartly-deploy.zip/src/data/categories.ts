import { CategoryId, CategoryInfo } from '../types';

export const CATEGORIES: CategoryInfo[] = [
  {
    id: 'dairy',
    nameDe: 'FRISCHE & MILCHPRODUKTE',
    nameEn: 'DAIRY & CHILLED',
    emoji: '🧀',
    badgeBg: 'bg-amber-50 text-amber-800',
    badgeText: 'text-amber-800',
  },
  {
    id: 'produce',
    nameDe: 'OBST & GEMÜSE',
    nameEn: 'VEGETABLES',
    emoji: '🥦',
    badgeBg: 'bg-emerald-50 text-emerald-800',
    badgeText: 'text-emerald-800',
  },
  {
    id: 'snacks',
    nameDe: 'FRÜCHTE & SNACKS',
    nameEn: 'FRUITS & SNACKS',
    emoji: '🍎',
    badgeBg: 'bg-rose-50 text-rose-800',
    badgeText: 'text-rose-800',
  },
  {
    id: 'bakery',
    nameDe: 'BÄCKEREI & BROT',
    nameEn: 'BAKERY & BREAD',
    emoji: '🥖',
    badgeBg: 'bg-yellow-50 text-yellow-800',
    badgeText: 'text-yellow-800',
  },
  {
    id: 'pantry',
    nameDe: 'VORRAT & TEIGWAREN',
    nameEn: 'PANTRY & DRY GOODS',
    emoji: '🥫',
    badgeBg: 'bg-orange-50 text-orange-800',
    badgeText: 'text-orange-800',
  },
  {
    id: 'drinks',
    nameDe: 'GETRÄNKE',
    nameEn: 'BEVERAGES',
    emoji: '🧃',
    badgeBg: 'bg-sky-50 text-sky-800',
    badgeText: 'text-sky-800',
  },
  {
    id: 'meat',
    nameDe: 'FLEISCH & FISCH',
    nameEn: 'MEAT & SEAFOOD',
    emoji: '🥩',
    badgeBg: 'bg-red-50 text-red-800',
    badgeText: 'text-red-800',
  },
  {
    id: 'frozen',
    nameDe: 'TIEFKÜHLKOST',
    nameEn: 'FROZEN',
    emoji: '❄️',
    badgeBg: 'bg-cyan-50 text-cyan-800',
    badgeText: 'text-cyan-800',
  },
  {
    id: 'household',
    nameDe: 'HAUSHALT & PFLEGE',
    nameEn: 'HOUSEHOLD & CARE',
    emoji: '🧼',
    badgeBg: 'bg-purple-50 text-purple-800',
    badgeText: 'text-purple-800',
  },
  {
    id: 'other',
    nameDe: 'SONSTIGES',
    nameEn: 'OTHER',
    emoji: '🛒',
    badgeBg: 'bg-slate-50 text-slate-800',
    badgeText: 'text-slate-800',
  },
];

export const getCategoryById = (id: CategoryId): CategoryInfo => {
  return CATEGORIES.find((c) => c.id === id) || CATEGORIES[CATEGORIES.length - 1];
};

export const COMMON_SUGGESTIONS = [
  { name: 'Oat Milk Barista Edition', category: 'dairy' as CategoryId, tag: 'Oatly', defaultQty: '2 cartons' },
  { name: 'Aged Gouda Cheese', category: 'dairy' as CategoryId, tag: 'Sarah', defaultQty: '200g' },
  { name: 'Vine Ripe Tomatoes', category: 'produce' as CategoryId, tag: 'Organic', defaultQty: '1 kg' },
  { name: 'Persian Cucumbers', category: 'produce' as CategoryId, tag: 'Crisp mini', defaultQty: '500g' },
  { name: 'Yukon Gold Potatoes', category: 'produce' as CategoryId, defaultQty: '2 kg bag' },
  { name: 'Honeycrisp Apples', category: 'snacks' as CategoryId, tag: 'Sweet & crisp', defaultQty: '6 pcs' },
  { name: 'Plain Greek Yogurt', category: 'dairy' as CategoryId, tag: '0% Fat', defaultQty: '4 x 150g' },
  { name: 'Sourdough Bread', category: 'bakery' as CategoryId, tag: 'Fresh', defaultQty: '1 loaf' },
  { name: 'Sparkling Mineral Water', category: 'drinks' as CategoryId, defaultQty: '6-pack' },
  { name: 'Pasta Fettuccine', category: 'pantry' as CategoryId, defaultQty: '500g' },
  { name: 'Extra Virgin Olive Oil', category: 'pantry' as CategoryId, defaultQty: '1 bottle' },
  { name: 'Organic Bananas', category: 'snacks' as CategoryId, defaultQty: '1 bunch' },
  { name: 'Butter', category: 'dairy' as CategoryId, defaultQty: '250g' },
  { name: 'Eggs (Free Range)', category: 'dairy' as CategoryId, defaultQty: '10 pcs' },
  { name: 'Dishwasher Tabs', category: 'household' as CategoryId, defaultQty: '1 pack' },
];
