import React, { useState, useMemo } from 'react';
import {
  Search,
  Check,
  ShoppingCart,
  X,
  Sparkles,
  Trash2,
} from 'lucide-react';
import { GroceryItem, Household, CategoryId } from '../types';
import { CATEGORIES } from '../data/categories';
import { Language, useTranslation } from '../data/translations';

interface MainListViewProps {
  household?: Household;
  items: GroceryItem[];
  onToggleItem: (itemId: string, checked: boolean) => void;
  onDeleteItem: (itemId: string) => void;
  onEditItem?: (item: GroceryItem) => void;
  onClearCompleted?: () => void;
  onOpenAddItem: () => void;
  onOpenShoppingMode: () => void;
  lang: Language;
}

export const MainListView: React.FC<MainListViewProps> = ({
  items,
  onToggleItem,
  onEditItem,
  onClearCompleted,
  onOpenShoppingMode,
  lang,
}) => {
  const t = useTranslation(lang);
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearch, setShowSearch] = useState(false);

  // Filter items by search query
  const filteredItems = useMemo(() => {
    if (!searchQuery.trim()) return items;
    const q = searchQuery.toLowerCase().trim();
    return items.filter(
      (item) =>
        item.name.toLowerCase().includes(q) ||
        (item.tag && item.tag.toLowerCase().includes(q)) ||
        (item.note && item.note.toLowerCase().includes(q))
    );
  }, [items, searchQuery]);

  // Separate active items from checked items
  const activeItems = useMemo(() => filteredItems.filter((i) => !i.checked), [filteredItems]);
  const checkedItems = useMemo(() => filteredItems.filter((i) => i.checked), [filteredItems]);

  const activeCount = useMemo(() => items.filter((i) => !i.checked).length, [items]);
  const totalCount = items.length;
  const isFridgeFull = totalCount > 0 && activeCount === 0;

  // Group ONLY active items by category
  const activeByCategory = useMemo(() => {
    const groups: { [key in CategoryId]?: GroceryItem[] } = {};
    for (const item of activeItems) {
      if (!groups[item.category]) {
        groups[item.category] = [];
      }
      groups[item.category]!.push(item);
    }
    return groups;
  }, [activeItems]);

  return (
    <main className="max-w-md mx-auto w-full px-4 pt-3 pb-28">
      {/* Title Row: Einkaufsliste stands in full width, Search button on right */}
      <div className="flex items-center justify-between mb-2">
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-stone-900">
          {t.groceries}
        </h1>

        {/* Search toggle button */}
        <button
          onClick={() => setShowSearch(!showSearch)}
          className="w-9 h-9 rounded-full bg-stone-200/60 hover:bg-stone-200/90 active:scale-95 text-stone-700 flex items-center justify-center transition-all shrink-0"
          aria-label="Search items"
        >
          <Search className="w-4 h-4" />
        </button>
      </div>

      {/* Einkaufsmodus Pill Bar right below the title */}
      <div className="mb-4">
        <button
          onClick={onOpenShoppingMode}
          className="w-full py-2.5 px-4 rounded-full bg-[#007AFF] hover:bg-blue-600 active:scale-[0.98] text-white text-xs font-semibold flex items-center justify-between shadow-[0_4px_16px_rgba(0,122,255,0.22)] transition-all"
        >
          <div className="flex items-center gap-2">
            <ShoppingCart className="w-4 h-4 stroke-[2.3]" />
            <span>{t.shoppingMode}</span>
          </div>
          <div className="flex items-center gap-1.5 font-mono text-[11px] bg-white/20 px-2.5 py-0.5 rounded-full">
            <span>{activeCount} {lang === 'de' ? 'offen' : 'to buy'}</span>
            <span className="text-xs">→</span>
          </div>
        </button>
      </div>

      {/* Search Bar Input (iOS Glass Style) */}
      {showSearch && (
        <div className="mb-4 relative animate-in fade-in duration-150">
          <input
            type="text"
            autoFocus
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t.searchPlaceholder}
            className="w-full pl-9 pr-8 py-2.5 bg-white/80 backdrop-blur-xl border border-black/[0.04] rounded-full text-xs text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-[#007AFF]/30 shadow-xs"
          />
          <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-3" />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-2.5 text-stone-400 hover:text-stone-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      )}

      {/* "Dein Kühlschrank ist voll" notice */}
      {isFridgeFull && (
        <div className="mb-4 p-4 rounded-[28px] bg-emerald-500/10 border border-emerald-500/20 text-emerald-800 flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-emerald-500 text-white flex items-center justify-center shrink-0">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <div className="text-xs font-bold">
              {lang === 'de' ? 'Dein Kühlschrank ist voll.' : 'Your fridge is full.'}
            </div>
            <div className="text-[11px] text-emerald-700">
              {lang === 'de'
                ? 'Alle Artikel wurden erfolgreich besorgt!'
                : 'All grocery items have been checked off!'}
            </div>
          </div>
        </div>
      )}

      {/* Empty State */}
      {items.length === 0 ? (
        <div className="p-8 text-center bg-white/80 backdrop-blur-xl rounded-[28px] border border-white/60 shadow-[0_8px_30px_rgb(0,0,0,0.04)] mt-4">
          <p className="text-stone-400 text-xs">{t.emptyList}</p>
          <p className="text-stone-400/80 text-[11px] mt-1">{t.emptyListSub}</p>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Active Items: Grouped by Category as iOS Inset Grouped Lists */}
          {CATEGORIES.map((cat) => {
            const catItems = activeByCategory[cat.id];
            if (!catItems || catItems.length === 0) return null;

            return (
              <div key={cat.id} className="space-y-1.5">
                {/* Category Header */}
                <div className="text-xs font-semibold uppercase tracking-wider text-stone-400 px-4">
                  {lang === 'de' ? cat.nameDe : cat.nameEn} ({catItems.length})
                </div>

                {/* Inset Grouped Container */}
                <div className="rounded-[28px] bg-white/80 backdrop-blur-xl shadow-[0_8px_30px_rgb(0,0,0,0.04)] border border-white/60 overflow-hidden divide-y divide-stone-200/50">
                  {catItems.map((item) => (
                    <div
                      key={item.id}
                      className="px-4 py-3 flex items-center justify-between gap-3 active:bg-stone-100/60 transition-all duration-150 ease-out"
                    >
                      {/* Left: Round check circle + emoji + name */}
                      <div className="flex items-center gap-3 min-w-0 flex-1">
                        <button
                          onClick={() => onToggleItem(item.id, true)}
                          className="w-6 h-6 rounded-full border-[1.5px] border-stone-300 hover:border-[#007AFF] flex items-center justify-center shrink-0 active:scale-90 transition-all"
                          aria-label="Mark done"
                        />

                        <span className="text-lg select-none shrink-0">{cat.emoji}</span>

                        <div
                          className="min-w-0 flex-1 cursor-pointer"
                          onClick={() => onEditItem?.(item)}
                        >
                          <div className="text-sm font-semibold text-stone-900 tracking-tight truncate hover:text-[#007AFF] transition-colors">
                            {item.name}
                          </div>
                          {(item.note || item.tag) && (
                            <div className="text-[11px] text-stone-400 truncate flex items-center gap-2 mt-0.5">
                              {item.note && <span>{item.note}</span>}
                              {item.note && item.tag && <span>•</span>}
                              {item.tag && <span className="font-medium text-stone-500">{item.tag}</span>}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Right: Compact rounded-full pill counter */}
                      <div className="shrink-0 flex items-center gap-2">
                        <span className="rounded-full bg-stone-100/80 px-2.5 py-1 text-xs font-semibold text-stone-600 font-mono shadow-2xs">
                          {item.quantity}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}

          {/* Checked Items: Compact, translucent and tucked below the active list */}
          {checkedItems.length > 0 && (
            <div className="pt-2 space-y-1.5 opacity-60 hover:opacity-100 transition-opacity">
              <div className="flex items-center justify-between px-4 text-xs font-semibold uppercase tracking-wider text-stone-400">
                <span>{lang === 'de' ? 'Abgehakt' : 'Checked'} ({checkedItems.length})</span>
                <button
                  onClick={onClearCompleted}
                  className="text-stone-400 hover:text-red-600 transition-colors flex items-center gap-1 active:scale-95"
                  title="Fertige löschen"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>{lang === 'de' ? 'Aufräumen' : 'Clear all'}</span>
                </button>
              </div>

              <div className="rounded-[28px] bg-white/40 backdrop-blur-md shadow-xs border border-white/40 overflow-hidden divide-y divide-stone-200/40">
                {checkedItems.map((item) => (
                  <div
                    key={item.id}
                    className="px-4 py-2 flex items-center justify-between gap-3 text-stone-400 text-xs"
                  >
                    <div className="flex items-center gap-2.5 min-w-0 flex-1">
                      <button
                        onClick={() => onToggleItem(item.id, false)}
                        className="w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center shrink-0 active:scale-90 transition-all"
                        aria-label="Uncheck"
                      >
                        <Check className="w-3 h-3 stroke-[3]" />
                      </button>
                      <span className="line-through truncate text-stone-400">
                        {item.name}
                      </span>
                    </div>

                    <span className="text-[11px] font-mono text-stone-400 shrink-0">
                      {item.quantity}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </main>
  );
};
