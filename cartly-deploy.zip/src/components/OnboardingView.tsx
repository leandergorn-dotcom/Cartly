import React, { useState } from 'react';
import {
  ShoppingBag,
  Users,
  Home,
  QrCode,
  ArrowRight,
  ShieldCheck,
  User,
  Sparkles,
  Globe,
  HelpCircle,
} from 'lucide-react';
import { Language, useTranslation } from '../data/translations';
import { getLocalizedHouseholdName, getRandomNickname } from '../utils/localizedName';

interface OnboardingViewProps {
  onJoin: (code: string, memberName: string) => Promise<void>;
  onCreate: (name: string, memberName: string) => Promise<void>;
  onOpenScanner: () => void;
  lang: Language;
  onToggleLang: () => void;
}

export const OnboardingView: React.FC<OnboardingViewProps> = ({
  onJoin,
  onCreate,
  onOpenScanner,
  lang,
  onToggleLang,
}) => {
  const t = useTranslation(lang);
  const [activeTab, setActiveTab] = useState<'join' | 'new'>('join');
  const [code, setCode] = useState('');
  const [householdName, setHouseholdName] = useState('');
  const [memberName, setMemberName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showHelp, setShowHelp] = useState(false);

  const handleJoinSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim()) {
      setError(lang === 'de' ? 'Bitte gib einen 6-stelligen Code ein.' : 'Please enter a 6-digit invite code.');
      return;
    }
    setError(null);
    setLoading(true);
    try {
      const finalName = memberName.trim() || getRandomNickname(lang);
      await onJoin(code.trim().toUpperCase(), finalName);
    } catch (err: any) {
      setError(err.message || (lang === 'de' ? 'Haushalt wurde nicht gefunden.' : 'Household could not be found.'));
    } finally {
      setLoading(false);
    }
  };

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!householdName.trim()) {
      setError(lang === 'de' ? 'Bitte gib einen Namen für die Familie ein.' : 'Please enter a household name.');
      return;
    }
    setError(null);
    setLoading(true);
    try {
      const finalMemberName = memberName.trim() || getRandomNickname(lang);
      await onCreate(householdName.trim(), finalMemberName);
    } catch (err: any) {
      setError(err.message || (lang === 'de' ? 'Fehler beim Erstellen.' : 'Error creating household.'));
    } finally {
      setLoading(false);
    }
  };

  const handleCodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (val.length > 3) {
      val = `${val.slice(0, 3)}-${val.slice(3, 6)}`;
    }
    setCode(val);
  };

  return (
    <div className="min-h-screen bg-[#F8F7F4] flex flex-col justify-between py-6 px-4 sm:px-6 relative selection:bg-blue-100">
      {/* Top bar: Help pill on left, Language switch pill on right */}
      <div className="w-full max-w-md mx-auto flex items-center justify-between pt-1">
        <button
          onClick={() => setShowHelp(!showHelp)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/75 hover:bg-white active:scale-95 border border-black/[0.04] text-[11px] font-semibold text-stone-600 shadow-xs transition-all"
          title="Help"
        >
          <HelpCircle className="w-3.5 h-3.5 text-[#007AFF]" />
          <span>{lang === 'de' ? 'Hilfe' : 'Help'}</span>
        </button>

        <button
          onClick={onToggleLang}
          className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-white/75 hover:bg-white active:scale-95 border border-black/[0.04] text-[11px] font-bold text-stone-700 uppercase font-mono shadow-xs transition-all"
          title={lang === 'de' ? 'Sprache wechseln / Switch Language' : 'Switch Language / Sprache wechseln'}
        >
          <Globe className="w-3.5 h-3.5 text-[#007AFF]" />
          <span>{lang}</span>
        </button>
      </div>

      {showHelp && (
        <div className="w-full max-w-md mx-auto mt-2 p-4 bg-white/90 backdrop-blur-xl border border-blue-100 rounded-[24px] text-xs text-stone-800 leading-relaxed shadow-sm animate-in fade-in">
          <strong className="text-[#007AFF]">{lang === 'de' ? 'Wie funktioniert Cartly?' : 'How does Cartly work?'}</strong>
          <p className="mt-1 text-stone-600">
            {lang === 'de'
              ? 'Erstelle einen gemeinsamen Haushalt oder trete einem bestehenden per Code bei. Jeder Haushalt hat einen QR-Code, den du ausdrucken oder an den Kühlschrank hängen kannst!'
              : 'Create a shared household or join via code. Every household has a QR code you can print or put on your fridge so family members can scan and shop together!'}
          </p>
        </div>
      )}

      {/* Main Container */}
      <div className="w-full max-w-md mx-auto my-auto py-6">
        {/* Brand Icon Lockup (Apple Style) */}
        <div className="flex flex-col items-center text-center mb-8">
          <div className="relative mb-4">
            <div className="w-20 h-20 bg-white/90 backdrop-blur-xl rounded-[28px] border border-white/80 flex items-center justify-center shadow-[0_8px_30px_rgb(0,0,0,0.04)]">
              <ShoppingBag className="w-9 h-9 text-[#007AFF] stroke-[2.2]" />
            </div>
            <div className="absolute -bottom-1 -right-1 w-7 h-7 bg-[#007AFF] rounded-full flex items-center justify-center shadow-md border-2 border-[#F8F7F4]">
              <Users className="w-3.5 h-3.5 text-white" />
            </div>
          </div>

          <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-stone-900">
            {t.appName}
          </h1>
          <p className="mt-1.5 text-base sm:text-lg font-medium text-stone-500 max-w-xs leading-snug">
            {t.appTagline}
          </p>
        </div>

        {/* Native iOS Segmented Control (rounded-full bg-stone-200/60 p-1) */}
        <div className="p-1 bg-stone-200/60 backdrop-blur-md rounded-full flex items-center gap-1 mb-5">
          <button
            type="button"
            onClick={() => {
              setActiveTab('join');
              setError(null);
            }}
            className={`flex-1 py-2 px-4 rounded-full text-xs sm:text-sm font-semibold flex items-center justify-center gap-1.5 active:scale-95 transition-all duration-200 ${
              activeTab === 'join'
                ? 'bg-white text-stone-900 shadow-sm'
                : 'text-stone-500 hover:text-stone-900'
            }`}
          >
            <span className="w-4 h-4 rounded-full bg-[#007AFF]/10 text-[#007AFF] flex items-center justify-center text-[10px] font-mono font-bold">
              #
            </span>
            <span>{t.joinHousehold}</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab('new');
              setError(null);
            }}
            className={`flex-1 py-2 px-4 rounded-full text-xs sm:text-sm font-semibold flex items-center justify-center gap-1.5 active:scale-95 transition-all duration-200 ${
              activeTab === 'new'
                ? 'bg-white text-stone-900 shadow-sm'
                : 'text-stone-500 hover:text-stone-900'
            }`}
          >
            <Home className="w-3.5 h-3.5 text-stone-500" />
            <span>{t.newHome}</span>
          </button>
        </div>

        {/* Card Body (Apple Widget: rounded-[32px], backdrop-blur-xl) */}
        <div className="bg-white/80 backdrop-blur-xl rounded-[32px] p-6 sm:p-7 shadow-[0_12px_40px_rgb(0,0,0,0.04)] border border-white/60">
          {error && (
            <div className="mb-5 p-3 rounded-2xl bg-red-50 border border-red-100 text-xs text-red-700 font-medium">
              {error}
            </div>
          )}

          {activeTab === 'join' ? (
            <form onSubmit={handleJoinSubmit} className="space-y-4">
              {/* Household Invite Code Input */}
              <div>
                <label className="block text-center text-[11px] font-semibold text-stone-400 tracking-wider uppercase mb-2">
                  {t.householdInviteCode}
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={code}
                    onChange={handleCodeChange}
                    maxLength={7}
                    placeholder={t.inviteCodePlaceholder}
                    className="w-full py-3.5 text-center text-2xl font-mono font-bold tracking-widest text-stone-900 bg-stone-100/70 border border-stone-200/50 rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#007AFF]/30 placeholder:text-stone-300 transition-all"
                  />
                </div>
                <p className="mt-1.5 text-center text-xs text-stone-400">
                  {t.inviteCodeHelp}
                </p>
              </div>

              {/* Optional Name */}
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  {t.yourLastName}
                </label>
                <div className="relative flex items-center">
                  <div className="absolute left-3.5 text-stone-400">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    value={memberName}
                    onChange={(e) => setMemberName(e.target.value)}
                    placeholder={lang === 'de' ? 'z. B. Sarah (leer für Spitznamen)' : 'e.g. Sarah (empty for nickname)'}
                    className="w-full pl-10 pr-4 py-3 bg-stone-100/70 border border-stone-200/50 rounded-2xl text-sm text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-[#007AFF]/30 transition-all"
                  />
                </div>
              </div>

              {/* Join Button (rounded-full) */}
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 px-4 rounded-full bg-[#007AFF] hover:bg-blue-600 text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-[0_4px_16px_rgba(0,122,255,0.25)] active:scale-[0.98] transition-all disabled:opacity-60"
              >
                <span>{loading ? '...' : t.joinHouseholdBtn}</span>
                <ArrowRight className="w-4 h-4 stroke-[2.2]" />
              </button>

              {/* Or Scan Divider */}
              <div className="relative flex py-1.5 items-center">
                <div className="flex-grow border-t border-stone-200/60"></div>
                <span className="flex-shrink mx-3 text-[10px] font-semibold text-stone-400 uppercase tracking-wider">
                  {t.orScan}
                </span>
                <div className="flex-grow border-t border-stone-200/60"></div>
              </div>

              {/* Scan Fridge QR Code Button (rounded-full) */}
              <button
                type="button"
                onClick={onOpenScanner}
                className="w-full py-3.5 px-4 rounded-full bg-stone-100/90 hover:bg-stone-200/80 active:scale-[0.98] text-stone-800 font-semibold text-sm flex items-center justify-center gap-2 border border-stone-200/40 transition-all"
              >
                <QrCode className="w-4 h-4 text-[#007AFF]" />
                <span>{t.scanHouseholdFridgeQr}</span>
              </button>
            </form>
          ) : (
            <form onSubmit={handleCreateSubmit} className="space-y-4">
              <div className="text-center mb-1">
                <h3 className="text-base font-bold text-stone-900">
                  {t.createHouseholdTitle}
                </h3>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  {t.householdNameLabel}
                </label>
                <div className="relative flex items-center">
                  <div className="absolute left-3.5 text-stone-400">
                    <Home className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    value={householdName}
                    onChange={(e) => setHouseholdName(e.target.value)}
                    placeholder={t.householdNamePlaceholder}
                    className="w-full pl-10 pr-4 py-3 bg-stone-100/70 border border-stone-200/50 rounded-2xl text-sm text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-[#007AFF]/30 transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  {t.yourLastName}
                </label>
                <div className="relative flex items-center">
                  <div className="absolute left-3.5 text-stone-400">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    value={memberName}
                    onChange={(e) => setMemberName(e.target.value)}
                    placeholder={t.yourLastNamePlaceholder}
                    className="w-full pl-10 pr-4 py-3 bg-stone-100/70 border border-stone-200/50 rounded-2xl text-sm text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-[#007AFF]/30 transition-all"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 px-4 rounded-full bg-[#007AFF] hover:bg-blue-600 text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-[0_4px_16px_rgba(0,122,255,0.25)] active:scale-[0.98] transition-all disabled:opacity-60"
              >
                <span>{loading ? '...' : t.createBtn}</span>
                <ArrowRight className="w-4 h-4 stroke-[2.2]" />
              </button>
            </form>
          )}

          {/* Quick Demo Families Bar */}
          <div className="mt-5 pt-4 border-t border-stone-100">
            <div className="flex items-center gap-1.5 mb-2 text-[11px] font-semibold text-stone-400 uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>{lang === 'de' ? 'Vorhandene Beispiel-Familien:' : 'Sample Households to Try:'}</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => onJoin('MLR-842', memberName || (lang === 'de' ? 'Familie Miller' : 'Miller'))}
                className="p-3 rounded-2xl bg-stone-50 hover:bg-stone-100/80 border border-stone-200/50 text-left active:scale-95 transition-all"
              >
                <div className="text-xs font-semibold text-[#007AFF]">
                  {getLocalizedHouseholdName('The Miller Family', lang)}
                </div>
                <div className="text-[10px] text-stone-400 font-mono mt-0.5">Code: MLR-842</div>
              </button>
              <button
                type="button"
                onClick={() => onJoin('KUK-123', memberName || (lang === 'de' ? 'Anna' : 'Leo'))}
                className="p-3 rounded-2xl bg-stone-50 hover:bg-stone-100/80 border border-stone-200/50 text-left active:scale-95 transition-all"
              >
                <div className="text-xs font-semibold text-amber-800">
                  {getLocalizedHouseholdName('Familie Kuku', lang)}
                </div>
                <div className="text-[10px] text-stone-400 font-mono mt-0.5">Code: KUK-123</div>
              </button>
            </div>
          </div>
        </div>

        {/* Security Footer Note */}
        <div className="mt-6 flex items-center justify-center gap-1.5 text-center text-stone-400">
          <ShieldCheck className="w-4 h-4 shrink-0 text-stone-400" />
          <span className="text-xs">{t.securityNote}</span>
        </div>
      </div>
    </div>
  );
};
