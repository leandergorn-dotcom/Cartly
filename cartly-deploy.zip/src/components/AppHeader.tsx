import React, { useState, useMemo } from 'react';
import {
  ShoppingBag,
  ChevronDown,
  QrCode,
  LogOut,
  ShoppingCart,
  Globe,
} from 'lucide-react';
import { Household } from '../types';
import { Language, useTranslation } from '../data/translations';
import { getLocalizedHouseholdName } from '../utils/localizedName';

interface AppHeaderProps {
  household: Household;
  lang: Language;
  onToggleLang: () => void;
  onOpenFridgeQr: () => void;
  onSwitchHousehold: () => void;
  isShoppingMode?: boolean;
}

export const AppHeader: React.FC<AppHeaderProps> = ({
  household,
  lang,
  onToggleLang,
  onOpenFridgeQr,
  onSwitchHousehold,
  isShoppingMode = false,
}) => {
  const t = useTranslation(lang);
  const [showHouseholdMenu, setShowHouseholdMenu] = useState(false);

  const localizedHouseholdName = useMemo(() => {
    return getLocalizedHouseholdName(household.name, lang);
  }, [household.name, lang]);

  return (
    <header className="sticky top-0 z-40 bg-[#F8F7F4]/80 backdrop-blur-2xl border-b border-black/[0.04] px-4 py-3">
      <div className="max-w-md mx-auto flex items-center justify-between">
        {/* Left: Cartly icon & Household switcher */}
        <div className="relative">
          <button
            onClick={() => setShowHouseholdMenu(!showHouseholdMenu)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/75 hover:bg-white active:scale-95 transition-all border border-black/[0.03] shadow-xs"
            aria-expanded={showHouseholdMenu}
            aria-label="Household menu"
          >
            <div className="w-6 h-6 rounded-full bg-[#007AFF]/10 text-[#007AFF] flex items-center justify-center shrink-0">
              <ShoppingBag className="w-3.5 h-3.5 stroke-[2.3]" />
            </div>
            <div className="text-left flex items-center gap-1.5">
              <span className="text-xs font-semibold text-stone-900 truncate max-w-[130px] sm:max-w-[160px]">
                {localizedHouseholdName}
              </span>
              <ChevronDown className="w-3.5 h-3.5 text-stone-400" />
            </div>
          </button>

          {/* Household Dropdown Menu (iOS Style) */}
          {showHouseholdMenu && (
            <div className="absolute left-0 mt-2 w-64 bg-white/95 backdrop-blur-2xl rounded-[28px] shadow-[0_12px_40px_rgba(0,0,0,0.12)] border border-black/[0.04] p-2 z-50 animate-in fade-in zoom-in-95 duration-150">
              <div className="px-3.5 py-2.5 border-b border-stone-100">
                <div className="text-xs font-bold text-stone-900">{localizedHouseholdName}</div>
                <div className="text-[11px] font-mono text-[#007AFF] mt-0.5">
                  Code: {household.id}
                </div>
              </div>

              <div className="py-1">
                <button
                  onClick={() => {
                    setShowHouseholdMenu(false);
                    onOpenFridgeQr();
                  }}
                  className="w-full px-3.5 py-2 text-left text-xs text-stone-700 hover:bg-stone-50 rounded-full flex items-center gap-2 active:scale-95 transition-all"
                >
                  <QrCode className="w-4 h-4 text-[#007AFF]" />
                  <span>{t.fridgeQrTitle}</span>
                </button>

                <button
                  onClick={() => {
                    setShowHouseholdMenu(false);
                    onSwitchHousehold();
                  }}
                  className="w-full px-3.5 py-2 text-left text-xs text-red-600 hover:bg-red-50 rounded-full flex items-center gap-2 active:scale-95 transition-all font-medium"
                >
                  <LogOut className="w-4 h-4 text-red-500" />
                  <span>{t.switchHousehold}</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Center: Shopping Mode badge if active */}
        {isShoppingMode && (
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#007AFF]/10 text-[#007AFF] text-xs font-semibold animate-in fade-in duration-200">
            <ShoppingCart className="w-3.5 h-3.5 stroke-[2.3]" />
            <span className="hidden xs:inline">{t.shoppingMode}</span>
          </div>
        )}

        {/* Right: Fixed Position Language switch pill */}
        <div className="flex items-center gap-2">
          <button
            onClick={onToggleLang}
            className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-white/75 hover:bg-white active:scale-95 border border-black/[0.03] text-[11px] font-bold text-stone-700 uppercase font-mono shadow-xs transition-all"
            title={lang === 'de' ? 'Sprache wechseln / Switch Language' : 'Switch Language / Sprache wechseln'}
          >
            <Globe className="w-3.5 h-3.5 text-[#007AFF]" />
            <span>{lang}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
