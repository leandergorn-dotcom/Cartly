import React, { useEffect, useMemo } from 'react';
import {
  ShoppingCart,
  Check,
  RotateCcw,
  MapPin,
  Sparkles,
  Trash2,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { GroceryItem, Household, CategoryId } from '../types';
import { CATEGORIES } from '../data/categories';
import { Language, useTranslation } from '../data/translations';
import { getLocalizedHouseholdName } from '../utils/localizedName';

interface ShoppingModeViewProps {
  household: Household;
  items: GroceryItem[];
  onToggleItem: (itemId: string, checked: boolean) => void;
  onFinish: () => void;
  onClearCompleted: () => void;
  onResetShopping: () => void;
  lang: Language;
}

export const ShoppingModeView: React.FC<ShoppingModeViewProps> = ({
  household,
  items,
  onToggleItem,
  onFinish,
  onClearCompleted,
  onResetShopping,
  lang,
}) => {
  const t = useTranslation(lang);

  const activeItems = useMemo(() => items.filter((i) => !i.checked), [items]);
  const completedItems = useMemo(() => items.filter((i) => i.checked), [items]);

  const totalCount = items.length;
  const completedCount = completedItems.length;
  const progressPercent = totalCount > 0 ? (completedCount / totalCount) * 100 : 0;
  const isAllDone = totalCount > 0 && completedCount === totalCount;

  // Trigger celebration confetti when all items are collected
  useEffect(() => {
    if (isAllDone) {
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#007AFF', '#34C759', '#FF9500', '#5856D6'],
        });
      } catch {
        // Safe fallback
      }
    }
  }, [isAllDone]);

  // Group active items by category
  const activeByCategory = useMemo(() => {
    const groups: { [key in CategoryId]?: GroceryItem[] } = {};
    for (const item of activeItems) {
      if (!groups[item.category]) {
        groups[item.category] = [];
      }
      groups[item.category]!.push(item);
    }
    return groups;
  }, [activeItems]);

  return (
    <main className="max-w-md mx-auto px-4 pt-3 pb-28 space-y-6">
        {/* iOS Blue Gradient Hero Card */}
        <div className="bg-gradient-to-br from-[#007AFF] to-[#0055c4] text-white rounded-[32px] p-6 shadow-[0_12px_40px_rgba(0,122,255,0.28)] border border-white/20 relative overflow-hidden">
          {/* Top row */}
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center gap-2.5">
              <ShoppingCart className="w-6 h-6 text-white stroke-[2.3]" />
              <h2 className="text-2xl font-bold tracking-tight text-white">
                {t.shoppingMode}
              </h2>
            </div>
            <button
              onClick={onFinish}
              className="px-4 py-1.5 rounded-full bg-white/20 hover:bg-white/30 text-white text-xs font-semibold backdrop-blur-md active:scale-95 transition-all"
            >
              {t.finishShopping}
            </button>
          </div>

          {/* Household Name Subtitle */}
          <div className="text-sm font-medium text-blue-100 mb-4">
            {getLocalizedHouseholdName(household.name, lang)}
          </div>

          {/* Smooth Continuous Progress Bar */}
          <div className="w-full bg-black/20 rounded-full h-2 mb-2.5 overflow-hidden">
            <div
              className="bg-white h-2 rounded-full transition-all duration-300 ease-out"
              style={{ width: `${progressPercent}%` }}
            />
          </div>

          {/* Progress Count */}
          <div className="text-xs font-medium text-blue-100 tabular-nums">
            {completedCount} {t.doneCount} {totalCount} {t.doneSuffix}
          </div>
        </div>

        {/* All items done banner */}
        {isAllDone && (
          <div className="p-6 bg-white/80 backdrop-blur-xl border border-white/60 rounded-[28px] text-center shadow-[0_8px_30px_rgb(0,0,0,0.04)] animate-in zoom-in-95 duration-200">
            <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-2 shadow-inner">
              <Sparkles className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-stone-900 tracking-tight">
              {t.allDoneTitle}
            </h3>
            <p className="text-xs text-stone-500 mt-0.5 font-medium">
              {t.allDoneSub}
            </p>
            <div className="mt-4 flex gap-2.5 justify-center">
              <button
                onClick={onResetShopping}
                className="px-4 py-2 rounded-full bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold flex items-center gap-1.5 active:scale-95 transition-all"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>{lang === 'de' ? 'Liste zurücksetzen' : 'Reset List'}</span>
              </button>
              <button
                onClick={onFinish}
                className="px-5 py-2 rounded-full bg-[#007AFF] text-white text-xs font-semibold hover:bg-blue-600 active:scale-95 shadow-sm transition-all"
              >
                {t.finishShopping}
              </button>
            </div>
          </div>
        )}

        {/* Inset Grouped Lists per Category */}
        {activeItems.length === 0 && !isAllDone ? (
          <div className="p-8 text-center bg-white/80 backdrop-blur-xl rounded-[28px] border border-white/60 shadow-[0_8px_30px_rgb(0,0,0,0.04)]">
            <p className="text-sm text-stone-500 font-medium">{t.emptyList}</p>
          </div>
        ) : (
          CATEGORIES.map((cat) => {
            const group = activeByCategory[cat.id];
            if (!group || group.length === 0) return null;

            return (
              <div key={cat.id}>
                {/* Category Header */}
                <div className="text-xs font-semibold uppercase tracking-wider text-stone-400 px-4 mb-1.5 flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span>{cat.emoji}</span>
                    <span>{lang === 'de' ? cat.nameDe : cat.nameEn}</span>
                  </div>
                  <span className="font-mono text-[11px]">{group.length}</span>
                </div>

                {/* Single Inset Grouped Container */}
                <div className="rounded-[28px] bg-white/80 backdrop-blur-xl shadow-[0_8px_30px_rgb(0,0,0,0.04)] border border-white/60 overflow-hidden divide-y divide-stone-200/50">
                  {group.map((item) => (
                    <div
                      key={item.id}
                      className="px-4 py-3.5 flex items-center justify-between gap-3 active:bg-stone-100/60 transition-all duration-150 ease-out"
                    >
                      {/* Round Check Circle */}
                      <button
                        onClick={() => onToggleItem(item.id, true)}
                        className="w-8 h-8 -ml-1 rounded-full flex items-center justify-center shrink-0 active:scale-90 transition-transform focus:outline-none"
                        aria-label={`Mark ${item.name} as bought`}
                      >
                        <div className="w-6 h-6 rounded-full border-[1.5px] border-emerald-500 hover:bg-emerald-50 transition-all flex items-center justify-center bg-white/50" />
                      </button>

                      {/* Title & Notes */}
                      <div className="flex-1 min-w-0 pr-1">
                        <div className="text-sm sm:text-base font-semibold text-stone-900 tracking-tight leading-snug truncate">
                          {item.name}
                        </div>

                        {item.note && (
                          <div className="mt-1 inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-50/90 text-[11px] text-amber-900 font-medium border border-amber-200/40 max-w-full">
                            <MapPin className="w-3 h-3 text-red-500 shrink-0" />
                            <span className="truncate">{item.note}</span>
                          </div>
                        )}
                      </div>

                      {/* Right: Compact rounded-full pill counter */}
                      <div className="shrink-0">
                        <span className="rounded-full bg-stone-100/80 px-2.5 py-1 text-xs font-semibold text-stone-600 font-mono shadow-2xs">
                          {item.quantity}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })
        )}

        {/* "SCHON IM WAGEN" Section as Inset Grouped List */}
        {completedItems.length > 0 && (
          <div className="pt-2 space-y-1.5">
            <div className="flex items-center justify-between px-4 text-xs font-semibold uppercase tracking-wider text-stone-400">
              <span>{t.alreadyInCart} ({completedItems.length})</span>
              <button
                onClick={onClearCompleted}
                className="text-stone-400 hover:text-red-600 transition-colors flex items-center gap-1 active:scale-95"
                title="Fertige löschen"
              >
                <Trash2 className="w-3 h-3" />
                <span>{lang === 'de' ? 'Aufräumen' : 'Clear all'}</span>
              </button>
            </div>

            <div className="rounded-[28px] bg-white/60 backdrop-blur-md shadow-xs border border-white/40 overflow-hidden divide-y divide-stone-200/40">
              {completedItems.map((item) => (
                <div
                  key={item.id}
                  className="px-4 py-3 flex items-center justify-between gap-3 text-stone-400"
                >
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    {/* Filled green checkmark */}
                    <div className="w-5 h-5 rounded-full bg-[#34C759] text-white flex items-center justify-center shrink-0">
                      <Check className="w-3 h-3 stroke-[3]" />
                    </div>

                    {/* Strikethrough text with quantity */}
                    <div className="text-xs sm:text-sm font-medium text-stone-400 line-through truncate">
                      <span className="font-mono font-bold mr-1.5">{item.quantity}</span>
                      <span>{item.name}</span>
                    </div>
                  </div>

                  {/* "Zurückholen" Pill Button */}
                  <button
                    onClick={() => onToggleItem(item.id, false)}
                    className="shrink-0 px-3 py-1 rounded-full bg-amber-50 hover:bg-amber-100 text-amber-800 text-xs font-semibold active:scale-95 transition-all"
                  >
                    {t.bringBack}
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
    </main>
  );
};
