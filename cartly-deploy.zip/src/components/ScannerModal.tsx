import React, { useEffect, useRef, useState } from 'react';
import { Camera, X, Upload, RefreshCw, AlertCircle, Sparkles } from 'lucide-react';
import jsQR from 'jsqr';
import { decodeQrFromFile } from '../utils/qr';
import { Language, useTranslation } from '../data/translations';

interface ScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScan: (code: string) => void;
  lang: Language;
}

export const ScannerModal: React.FC<ScannerModalProps> = ({
  isOpen,
  onClose,
  onScan,
  lang,
}) => {
  const t = useTranslation(lang);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const animationFrameRef = useRef<number | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const extractCode = (raw: string): string => {
    const match = raw.match(/[A-Z0-9]{3}-[A-Z0-9]{3}/i);
    if (match) return match[0].toUpperCase();
    return raw.trim().toUpperCase();
  };

  const handleDetectedCode = (code: string) => {
    const clean = extractCode(code);
    if (clean) {
      try {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.frequency.setValueAtTime(800, audioCtx.currentTime);
        gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.12);
      } catch {
        // Safe fallback
      }
      onScan(clean);
      stopCamera();
      onClose();
    }
  };

  const startCamera = async () => {
    setCameraError(null);
    try {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: facingMode },
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
      });

      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute('playsinline', 'true');
        await videoRef.current.play();
        setIsScanning(true);
        requestAnimationFrame(tick);
      }
    } catch (err: any) {
      console.warn('Camera stream error:', err);
      setCameraError(
        lang === 'de'
          ? 'Kamera konnte nicht gestartet werden (evtl. blockiert oder nicht vorhanden). Du kannst ein Bild hochladen oder Democodes nutzen.'
          : 'Unable to start camera. You can upload an image or select a demo code below.'
      );
      setIsScanning(false);
    }
  };

  const stopCamera = () => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setIsScanning(false);
  };

  const tick = () => {
    if (videoRef.current && videoRef.current.readyState === videoRef.current.HAVE_ENOUGH_DATA) {
      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d', { willReadFrequently: true });
        if (ctx) {
          canvas.height = videoRef.current.videoHeight;
          canvas.width = videoRef.current.videoWidth;
          ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);

          const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
          const code = jsQR(imageData.data, imageData.width, imageData.height, {
            inversionAttempts: 'dontInvert',
          });

          if (code && code.data) {
            handleDetectedCode(code.data);
            return;
          }
        }
      }
    }
    if (isOpen) {
      animationFrameRef.current = requestAnimationFrame(tick);
    }
  };

  useEffect(() => {
    if (isOpen) {
      startCamera();
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [isOpen, facingMode]);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const decoded = await decodeQrFromFile(file);
      if (decoded) {
        handleDetectedCode(decoded);
      } else {
        alert(
          lang === 'de'
            ? 'Kein QR-Code im Bild gefunden. Bitte ein deutlicheres Foto wählen.'
            : 'No QR code found in the image. Please try another photo.'
        );
      }
    } catch (err) {
      console.error(err);
      alert(lang === 'de' ? 'Fehler beim Lesen des Bildes.' : 'Failed to read image.');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/40 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-white/95 backdrop-blur-2xl rounded-[32px] overflow-hidden shadow-[0_20px_60px_rgba(0,0,0,0.12)] border border-black/[0.04] flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-100">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-[#007AFF]/10 flex items-center justify-center text-[#007AFF]">
              <Camera className="w-4 h-4" />
            </div>
            <h2 className="text-base font-bold text-stone-900 tracking-tight">
              {t.cameraScanTitle}
            </h2>
          </div>
          <button
            onClick={() => {
              stopCamera();
              onClose();
            }}
            className="w-8 h-8 rounded-full flex items-center justify-center text-stone-400 hover:text-stone-700 hover:bg-stone-100 active:scale-95 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Viewfinder Area */}
        <div className="relative aspect-square w-full bg-stone-950 overflow-hidden flex items-center justify-center">
          <video
            ref={videoRef}
            className="absolute inset-0 w-full h-full object-cover"
            muted
            playsInline
          />
          <canvas ref={canvasRef} className="hidden" />

          {/* Scanner Overlay Frame (Apple rounded box) */}
          <div className="relative z-10 w-64 h-64 border-2 border-white/60 rounded-[32px] flex items-center justify-center overflow-hidden shadow-2xl">
            <div className="absolute top-0 left-0 w-7 h-7 border-t-4 border-l-4 border-[#007AFF] rounded-tl-2xl" />
            <div className="absolute top-0 right-0 w-7 h-7 border-t-4 border-r-4 border-[#007AFF] rounded-tr-2xl" />
            <div className="absolute bottom-0 left-0 w-7 h-7 border-b-4 border-l-4 border-[#007AFF] rounded-bl-2xl" />
            <div className="absolute bottom-0 right-0 w-7 h-7 border-b-4 border-r-4 border-[#007AFF] rounded-br-2xl" />

            {/* Laser Line */}
            {isScanning && (
              <div className="absolute w-full h-0.5 bg-gradient-to-r from-transparent via-[#007AFF] to-transparent shadow-[0_0_12px_#007AFF] animate-bounce" />
            )}
          </div>

          {/* Camera Error / Permission Notice */}
          {cameraError && (
            <div className="absolute inset-0 z-20 bg-stone-900/90 flex flex-col items-center justify-center p-6 text-center text-white">
              <AlertCircle className="w-10 h-10 text-amber-400 mb-3" />
              <p className="text-sm text-stone-200 max-w-xs mb-4">{cameraError}</p>
              <button
                onClick={() => fileInputRef.current?.click()}
                className="px-5 py-2.5 bg-[#007AFF] text-white rounded-full text-xs font-semibold hover:bg-blue-600 active:scale-95 transition-all flex items-center gap-2"
              >
                <Upload className="w-4 h-4" />
                {t.uploadImageFallback}
              </button>
            </div>
          )}

          {/* Camera flip control */}
          <button
            onClick={() => setFacingMode((prev) => (prev === 'environment' ? 'user' : 'environment'))}
            className="absolute bottom-4 right-4 z-20 w-10 h-10 rounded-full bg-black/60 text-white flex items-center justify-center backdrop-blur-sm active:scale-90 hover:bg-black/80 transition-all"
            title="Flip camera"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>

        {/* Footer actions */}
        <div className="p-5 bg-stone-50/80 flex flex-col gap-3">
          <div className="text-center">
            <p className="text-xs text-stone-500">{t.cameraScanSub}</p>
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleFileUpload}
          />

          <div className="flex gap-2">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex-1 py-2.5 px-4 rounded-full bg-white border border-stone-200/60 text-xs font-semibold text-stone-700 hover:bg-stone-100 active:scale-95 flex items-center justify-center gap-1.5 transition-all shadow-2xs"
            >
              <Upload className="w-4 h-4 text-stone-500" />
              {t.uploadImageFallback}
            </button>
          </div>

          {/* Quick Demo QR Test Buttons */}
          <div className="pt-2 border-t border-stone-200/60">
            <div className="flex items-center gap-1 mb-2 text-[11px] font-semibold text-stone-400 uppercase tracking-wider">
              <Sparkles className="w-3 h-3 text-amber-500" />
              <span>{lang === 'de' ? 'Schnelltest ohne Kamera:' : 'Quick Test without Camera:'}</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => handleDetectedCode('MLR-842')}
                className="p-2.5 rounded-2xl bg-white border border-stone-200/60 text-left active:scale-95 hover:bg-stone-50 transition-all shadow-2xs"
              >
                <div className="text-xs font-semibold text-[#007AFF]">The Miller Family</div>
                <div className="text-[10px] text-stone-400 font-mono">MLR-842</div>
              </button>
              <button
                onClick={() => handleDetectedCode('KUK-123')}
                className="p-2.5 rounded-2xl bg-white border border-stone-200/60 text-left active:scale-95 hover:bg-stone-50 transition-all shadow-2xs"
              >
                <div className="text-xs font-semibold text-amber-800">Familie Kuku</div>
                <div className="text-[10px] text-stone-400 font-mono">KUK-123</div>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
