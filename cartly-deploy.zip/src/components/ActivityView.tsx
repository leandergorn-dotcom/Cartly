import React from 'react';
import { ActivityLog, Household } from '../types';
import { Language, useTranslation } from '../data/translations';
import { Plus, Check, RotateCcw, Trash2, UserPlus, Clock } from 'lucide-react';

interface ActivityViewProps {
  household: Household;
  activities: ActivityLog[];
  lang: Language;
}

export const ActivityView: React.FC<ActivityViewProps> = ({
  household,
  activities,
  lang,
}) => {
  const t = useTranslation(lang);

  const formatTime = (ts: number) => {
    const diff = Math.floor((Date.now() - ts) / 1000);
    if (diff < 60) return lang === 'de' ? 'Gerade eben' : 'Just now';
    if (diff < 3600) return `${Math.floor(diff / 60)} min`;
    if (diff < 86400) return `${Math.floor(diff / 3600)} h`;
    return new Date(ts).toLocaleDateString(lang === 'de' ? 'de-DE' : 'en-US', {
      day: 'numeric',
      month: 'short',
    });
  };

  const getActionBadge = (type: ActivityLog['type']) => {
    switch (type) {
      case 'add':
        return {
          icon: <Plus className="w-3.5 h-3.5 text-[#007AFF]" />,
          bg: 'bg-[#007AFF]/10',
          text: lang === 'de' ? 'hinzugefügt' : 'added',
        };
      case 'check':
        return {
          icon: <Check className="w-3.5 h-3.5 text-emerald-600" />,
          bg: 'bg-emerald-50',
          text: lang === 'de' ? 'in den Wagen gelegt' : 'checked off',
        };
      case 'uncheck':
        return {
          icon: <RotateCcw className="w-3.5 h-3.5 text-amber-600" />,
          bg: 'bg-amber-50',
          text: lang === 'de' ? 'zurückgelegt' : 'returned',
        };
      case 'delete':
        return {
          icon: <Trash2 className="w-3.5 h-3.5 text-red-600" />,
          bg: 'bg-red-50',
          text: lang === 'de' ? 'gelöscht' : 'removed',
        };
      case 'join':
        return {
          icon: <UserPlus className="w-3.5 h-3.5 text-purple-600" />,
          bg: 'bg-purple-50',
          text: lang === 'de' ? 'ist beigetreten' : 'joined',
        };
      default:
        return {
          icon: <Clock className="w-3.5 h-3.5 text-stone-600" />,
          bg: 'bg-stone-50',
          text: '',
        };
    }
  };

  return (
    <main className="max-w-md mx-auto px-4 pt-3 pb-28 space-y-4">
      <div className="text-center pb-1">
        <h2 className="text-2xl font-bold text-stone-900 tracking-tight">
          {t.recentActivity}
        </h2>
        <p className="text-xs text-stone-400 mt-0.5">
          {household.name} • Code: {household.id}
        </p>
      </div>

      {activities.length === 0 ? (
        <div className="p-8 text-center bg-white/80 backdrop-blur-xl rounded-[28px] border border-white/60 shadow-[0_8px_30px_rgb(0,0,0,0.04)]">
          <p className="text-xs text-stone-400">{t.noActivityYet}</p>
        </div>
      ) : (
        <div className="rounded-[28px] bg-white/80 backdrop-blur-xl shadow-[0_8px_30px_rgb(0,0,0,0.04)] border border-white/60 overflow-hidden divide-y divide-stone-200/50">
          {activities.map((act) => {
            const badge = getActionBadge(act.type);
            return (
              <div key={act.id} className="px-4 py-3.5 flex items-center justify-between gap-3 active:bg-stone-100/50 transition-colors">
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-8 h-8 rounded-full ${badge.bg} flex items-center justify-center shrink-0`}
                  >
                    {badge.icon}
                  </div>
                  <div className="truncate">
                    <div className="text-xs text-stone-800">
                      <span className="font-semibold text-stone-900">{act.memberName}</span>{' '}
                      <span className="text-stone-500">{badge.text}</span>
                      {act.itemName && (
                        <span className="font-semibold text-stone-900 ml-1">
                          "{act.itemName}"
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="shrink-0 text-[11px] text-stone-400 font-mono">
                  {formatTime(act.timestamp)}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </main>
  );
};
