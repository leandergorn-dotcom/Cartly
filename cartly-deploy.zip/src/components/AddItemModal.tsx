import React, { useState, useRef, useEffect } from 'react';
import { X, Plus, Sparkles, Check, Hash, AlignLeft, Trash2 } from 'lucide-react';
import { CategoryId, GroceryItem } from '../types';
import { CATEGORIES, COMMON_SUGGESTIONS } from '../data/categories';
import { Language, useTranslation } from '../data/translations';
import { autoCategorize } from '../utils/categorize';

interface AddItemModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (data: {
    name: string;
    category: CategoryId;
    quantity: string;
    note?: string;
  }) => Promise<void>;
  itemToEdit?: GroceryItem | null;
  onUpdate?: (itemId: string, fields: Partial<GroceryItem>) => Promise<void>;
  onDelete?: (itemId: string) => void;
  lang: Language;
  onTyping?: (isTyping: boolean) => void;
}

export const AddItemModal: React.FC<AddItemModalProps> = ({
  isOpen,
  onClose,
  onAdd,
  itemToEdit,
  onUpdate,
  onDelete,
  lang,
  onTyping,
}) => {
  const t = useTranslation(lang);
  const [name, setName] = useState('');
  const [quantity, setQuantity] = useState('1x');
  const [note, setNote] = useState('');
  const [customCategory, setCustomCategory] = useState<CategoryId | null>(null);
  const [loading, setLoading] = useState(false);
  const [recentlyAdded, setRecentlyAdded] = useState<string[]>([]);
  const [showCategoryPicker, setShowCategoryPicker] = useState(false);

  const nameInputRef = useRef<HTMLInputElement>(null);

  // Auto-calculated category based on name
  const detectedCategory: CategoryId = customCategory || autoCategorize(name);
  const categoryInfo = CATEGORIES.find((c) => c.id === detectedCategory) || CATEGORIES[CATEGORIES.length - 1];

  useEffect(() => {
    if (isOpen) {
      if (itemToEdit) {
        setName(itemToEdit.name);
        setQuantity(itemToEdit.quantity || '1x');
        setNote(itemToEdit.note || '');
        setCustomCategory(itemToEdit.category);
        setRecentlyAdded([]);
      } else {
        setRecentlyAdded([]);
        setName('');
        setQuantity('1x');
        setNote('');
        setCustomCategory(null);
      }
      setShowCategoryPicker(false);
      setTimeout(() => nameInputRef.current?.focus(), 80);
    }
  }, [isOpen, itemToEdit]);

  if (!isOpen) return null;

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!name.trim()) return;

    setLoading(true);
    try {
      if (itemToEdit && onUpdate) {
        await onUpdate(itemToEdit.id, {
          name: name.trim(),
          category: detectedCategory,
          quantity: quantity.trim() || '1x',
          note: note.trim() || undefined,
        });
        onClose();
      } else {
        const itemName = name.trim();
        await onAdd({
          name: itemName,
          category: detectedCategory,
          quantity: quantity.trim() || '1x',
          note: note.trim() || undefined,
        });

        // Keep dialog OPEN in add mode so user can add multiple items in a row
        setRecentlyAdded((prev) => [itemName, ...prev]);
        setName('');
        setQuantity('1x');
        setNote('');
        setCustomCategory(null);
        setShowCategoryPicker(false);
        if (onTyping) onTyping(false);

        setTimeout(() => nameInputRef.current?.focus(), 50);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteItem = () => {
    if (itemToEdit && onDelete) {
      onDelete(itemToEdit.id);
      onClose();
    }
  };

  const applySuggestion = (sug: typeof COMMON_SUGGESTIONS[0]) => {
    setName(sug.name);
    setCustomCategory(sug.category);
    if (sug.defaultQty) setQuantity(sug.defaultQty);
    if (sug.tag) setNote(sug.tag);
    nameInputRef.current?.focus();
  };

  const isEditing = Boolean(itemToEdit);

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-stone-900/40 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-white/95 backdrop-blur-2xl rounded-t-[32px] sm:rounded-[32px] shadow-[0_20px_60px_rgba(0,0,0,0.12)] border border-black/[0.04] overflow-hidden flex flex-col max-h-[92vh]">
        {/* iOS Drag Handle for mobile sheet */}
        <div className="w-9 h-1.5 bg-stone-300/80 rounded-full mx-auto mt-3 sm:hidden" />

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-200/50">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-[#007AFF]/10 text-[#007AFF] flex items-center justify-center">
              {isEditing ? <Hash className="w-4 h-4 stroke-[2.2]" /> : <Plus className="w-4 h-4 stroke-[2.5]" />}
            </div>
            <div>
              <h2 className="text-lg font-bold text-stone-900 tracking-tight">
                {isEditing ? (lang === 'de' ? 'Artikel bearbeiten' : 'Edit Grocery Item') : t.newItemTitle}
              </h2>
              <div className="text-[11px] text-stone-400 font-medium">
                {isEditing
                  ? (lang === 'de' ? 'Menge, Notiz oder Kategorie anpassen' : 'Update details or remove item')
                  : (lang === 'de' ? 'Mehrere Artikel hintereinander hinzufügen' : 'Add multiple items one after another')}
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-3.5 py-1.5 rounded-full bg-stone-100 hover:bg-stone-200/80 active:scale-95 text-stone-700 text-xs font-semibold transition-all"
          >
            {lang === 'de' ? 'Fertig' : 'Done'}
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto">
          {/* Quick Suggestions (only in create mode) */}
          {!isEditing && (
            <div>
              <div className="flex items-center gap-1.5 mb-2 text-[11px] font-semibold text-stone-400 uppercase tracking-wider">
                <Sparkles className="w-3 h-3 text-amber-500" />
                <span>{lang === 'de' ? 'Schnellvorschläge:' : 'Quick suggestions:'}</span>
              </div>
              <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
                {COMMON_SUGGESTIONS.slice(0, 7).map((sug) => (
                  <button
                    key={sug.name}
                    type="button"
                    onClick={() => applySuggestion(sug)}
                    className="px-3 py-1.5 rounded-full bg-stone-100/90 hover:bg-[#007AFF]/10 hover:text-[#007AFF] text-stone-700 whitespace-nowrap active:scale-95 transition-all flex items-center gap-1.5 font-medium"
                  >
                    <span>{CATEGORIES.find((c) => c.id === sug.category)?.emoji}</span>
                    <span>{sug.name}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Item Name Input with Auto-detected Category Pill */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-semibold text-stone-700">
                {t.itemNameLabel} *
              </label>
              {/* Category selector pill */}
              <button
                type="button"
                onClick={() => setShowCategoryPicker(!showCategoryPicker)}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-stone-100 hover:bg-stone-200/80 active:scale-95 text-stone-700 text-xs font-medium transition-all"
                title={lang === 'de' ? 'Kategorie manuell anpassen' : 'Change category manually'}
              >
                <span>{categoryInfo.emoji}</span>
                <span>{lang === 'de' ? categoryInfo.nameDe : categoryInfo.nameEn}</span>
              </button>
            </div>

            <input
              ref={nameInputRef}
              type="text"
              required
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                setCustomCategory(null);
                if (onTyping) onTyping(true);
              }}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleSubmit();
                }
              }}
              placeholder={t.itemNamePlaceholder}
              className="w-full px-4 py-3 bg-stone-100/70 border border-stone-200/60 rounded-2xl text-sm text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-[#007AFF]/30 focus:border-[#007AFF] transition-all"
            />
          </div>

          {/* Optional Category Picker Grid */}
          {showCategoryPicker && (
            <div className="p-3 bg-stone-50/90 border border-stone-200/60 rounded-2xl animate-in fade-in duration-150">
              <div className="text-[10px] font-bold text-stone-400 uppercase tracking-wider mb-2">
                {lang === 'de' ? 'Kategorie manuell wählen:' : 'Select category manually:'}
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                {CATEGORIES.map((cat) => (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => {
                      setCustomCategory(cat.id);
                      setShowCategoryPicker(false);
                    }}
                    className={`p-2 rounded-xl text-left text-xs flex items-center gap-2 active:scale-95 transition-all ${
                      detectedCategory === cat.id
                        ? 'bg-[#007AFF] text-white font-semibold shadow-sm'
                        : 'bg-white text-stone-700 hover:bg-stone-100 border border-stone-200/40'
                    }`}
                  >
                    <span>{cat.emoji}</span>
                    <span className="truncate">{lang === 'de' ? cat.nameDe : cat.nameEn}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Quantity & Note Row (Brand removed, continuous rounded geometry) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Quantity */}
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                {t.quantityLabel}
              </label>
              <div className="space-y-1.5">
                <input
                  type="text"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                  placeholder={t.quantityPlaceholder}
                  className="w-full px-3.5 py-2.5 bg-stone-100/70 border border-stone-200/60 rounded-2xl text-sm text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-[#007AFF]/30 transition-all font-mono"
                />
                <div className="flex gap-1.5">
                  {['1x', '2x', '500g', '1 kg'].map((q) => (
                    <button
                      key={q}
                      type="button"
                      onClick={() => setQuantity(q)}
                      className="px-2.5 py-1 rounded-full bg-stone-100 text-[11px] font-medium text-stone-600 hover:bg-stone-200 active:scale-95 transition-all"
                    >
                      {q}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Note */}
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                {t.noteLabel}
              </label>
              <div className="relative">
                <div className="absolute left-3.5 top-3 text-stone-400">
                  <AlignLeft className="w-3.5 h-3.5" />
                </div>
                <input
                  type="text"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder={lang === 'de' ? 'z. B. Marke oder Laden' : 'e.g. brand or store'}
                  className="w-full pl-9 pr-3.5 py-2.5 bg-stone-100/70 border border-stone-200/60 rounded-2xl text-sm text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-[#007AFF]/30 transition-all"
                />
              </div>
            </div>
          </div>

          {/* Action Buttons (rounded-full) */}
          <div className="pt-2 flex flex-col gap-2.5">
            <div className="flex gap-2.5">
              <button
                type="submit"
                disabled={loading || !name.trim()}
                className="flex-1 py-3.5 px-5 rounded-full bg-[#007AFF] hover:bg-blue-600 text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-[0_4px_16px_rgba(0,122,255,0.25)] active:scale-[0.97] transition-all disabled:opacity-50"
              >
                {isEditing ? (
                  <span>{loading ? '...' : lang === 'de' ? 'Änderungen speichern' : 'Save Changes'}</span>
                ) : (
                  <>
                    <Plus className="w-4 h-4 stroke-[2.5]" />
                    <span>{loading ? '...' : lang === 'de' ? 'Hinzufügen (bleibt offen)' : 'Add Item (keeps open)'}</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={onClose}
                className="py-3.5 px-5 rounded-full bg-stone-100 hover:bg-stone-200/80 text-stone-700 font-medium text-sm active:scale-[0.97] transition-all"
              >
                {lang === 'de' ? 'Fertig' : 'Done'}
              </button>
            </div>

            {/* Delete button (only in edit mode per Progressive Disclosure!) */}
            {isEditing && (
              <button
                type="button"
                onClick={handleDeleteItem}
                className="w-full py-2.5 px-4 rounded-full bg-red-50 hover:bg-red-100 text-red-600 font-medium text-xs flex items-center justify-center gap-1.5 active:scale-[0.97] transition-all mt-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{lang === 'de' ? 'Diesen Artikel von der Liste löschen' : 'Delete item from list'}</span>
              </button>
            )}
          </div>

          {/* Recently Added Items in this session */}
          {recentlyAdded.length > 0 && (
            <div className="pt-3 border-t border-stone-100">
              <div className="flex items-center gap-1.5 text-[11px] font-semibold text-stone-400 uppercase tracking-wider mb-2">
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                <span>
                  {lang === 'de'
                    ? `Gerade hinzugefügt (${recentlyAdded.length}):`
                    : `Just added (${recentlyAdded.length}):`}
                </span>
              </div>
              <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto">
                {recentlyAdded.map((item, idx) => (
                  <span
                    key={`${item}-${idx}`}
                    className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 text-xs font-medium border border-emerald-100/60"
                  >
                    <span>✓</span>
                    <span>{item}</span>
                  </span>
                ))}
              </div>
            </div>
          )}
        </form>
      </div>
    </div>
  );
};
