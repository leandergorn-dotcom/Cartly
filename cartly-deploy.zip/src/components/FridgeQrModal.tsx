import React, { useEffect, useState } from 'react';
import { X, Copy, Check, Share2, Printer, QrCode } from 'lucide-react';
import { generateQrDataUrl } from '../utils/qr';
import { Household } from '../types';
import { Language, useTranslation } from '../data/translations';
import { getLocalizedHouseholdName } from '../utils/localizedName';

interface FridgeQrModalProps {
  isOpen: boolean;
  onClose: () => void;
  household: Household;
  lang: Language;
}

export const FridgeQrModal: React.FC<FridgeQrModalProps> = ({
  isOpen,
  onClose,
  household,
  lang,
}) => {
  const t = useTranslation(lang);
  const [qrUrl, setQrUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);

  const joinLink = typeof window !== 'undefined'
    ? `${window.location.origin}?code=${encodeURIComponent(household.id)}`
    : '';

  useEffect(() => {
    if (isOpen && household) {
      generateQrDataUrl(joinLink)
        .then(setQrUrl)
        .catch(console.error);
    }
  }, [isOpen, household, joinLink]);

  if (!isOpen) return null;

  const localizedName = getLocalizedHouseholdName(household.name, lang);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(household.id);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Cartly - ${localizedName}`,
          text: lang === 'de'
            ? `Tritt unserer Familien-Einkaufsliste auf Cartly bei! Code: ${household.id}`
            : `Join our family grocery list on Cartly! Code: ${household.id}`,
          url: joinLink,
        });
      } catch {
        // User cancelled share
      }
    } else {
      navigator.clipboard.writeText(joinLink);
      alert(lang === 'de' ? 'Link in Zwischenablage kopiert!' : 'Link copied to clipboard!');
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/40 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-white/95 backdrop-blur-2xl w-full max-w-sm rounded-[32px] shadow-[0_20px_60px_-15px_rgba(0,0,0,0.15)] border border-white/80 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 pt-6 pb-2">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center">
              <QrCode className="w-4 h-4" />
            </div>
            <h2 className="text-lg font-bold text-stone-900 tracking-tight">
              {t.fridgeQrTitle}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-stone-100 hover:bg-stone-200 text-stone-500 flex items-center justify-center transition-colors active:scale-95"
            aria-label={t.close}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="px-6 text-xs text-stone-500 mb-4 leading-relaxed">
          {t.fridgeQrSub}
        </p>

        {/* The Card (for display and printing) */}
        <div className="px-6 pb-2">
          <div
            id="cartly-fridge-sticker"
            className="bg-white rounded-[24px] p-6 text-center border border-stone-200/60 shadow-[0_4px_20px_rgb(0,0,0,0.03)] flex flex-col items-center"
          >
            <div className="text-xs font-semibold uppercase tracking-wider text-blue-600 mb-1">
              Cartly
            </div>
            <h3 className="text-xl font-bold text-stone-900 tracking-tight mb-4">
              {localizedName}
            </h3>

            {/* QR Code Container */}
            <div className="bg-stone-50 p-3 rounded-[20px] border border-stone-100 inline-block shadow-inner mb-4">
              {qrUrl ? (
                <img
                  src={qrUrl}
                  alt={`QR Code for ${localizedName}`}
                  className="w-44 h-44 rounded-xl block mx-auto"
                />
              ) : (
                <div className="w-44 h-44 flex items-center justify-center text-stone-400 text-xs">
                  {lang === 'de' ? 'Generiere...' : 'Generating...'}
                </div>
              )}
            </div>

            {/* Household Code */}
            <div className="w-full">
              <p className="text-[11px] font-medium text-stone-400 uppercase tracking-wider mb-1">
                {lang === 'de' ? 'Haushaltscode' : 'Household Code'}
              </p>
              <div className="flex items-center justify-center gap-2 bg-stone-100/80 px-4 py-2 rounded-full border border-stone-200/50">
                <span className="font-mono text-base font-bold tracking-widest text-stone-900">
                  {household.id}
                </span>
                <button
                  onClick={handleCopyCode}
                  className="p-1 rounded-full hover:bg-stone-200/80 text-stone-600 transition-colors active:scale-90"
                  title={t.copyCode}
                >
                  {copied ? (
                    <Check className="w-4 h-4 text-emerald-600" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="p-6 pt-3 flex flex-col gap-2 no-print">
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={handleCopyCode}
              className="flex items-center justify-center gap-1.5 py-2.5 px-4 rounded-full bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold transition-all active:scale-[0.97]"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{t.codeCopied}</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>{t.copyCode}</span>
                </>
              )}
            </button>

            <button
              onClick={handleShare}
              className="flex items-center justify-center gap-1.5 py-2.5 px-4 rounded-full bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold transition-all active:scale-[0.97]"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>{t.shareLink}</span>
            </button>
          </div>

          <button
            onClick={handlePrint}
            className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-full bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-md shadow-blue-500/20 transition-all active:scale-[0.97]"
          >
            <Printer className="w-4 h-4" />
            <span>{t.printCard}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
