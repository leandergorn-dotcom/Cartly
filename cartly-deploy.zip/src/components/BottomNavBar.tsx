import React from 'react';
import { ShoppingBag, Bell, QrCode } from 'lucide-react';
import { Language, useTranslation } from '../data/translations';

interface BottomNavBarProps {
  activeTab: 'lists' | 'activity' | 'shopping' | 'fridge';
  isShoppingMode: boolean;
  onSelectTab: (tab: 'lists' | 'activity' | 'fridge') => void;
  lang: Language;
}

export const BottomNavBar: React.FC<BottomNavBarProps> = ({
  activeTab,
  isShoppingMode,
  onSelectTab,
  lang,
}) => {
  const t = useTranslation(lang);

  const isListsActive = (activeTab === 'lists' || isShoppingMode);

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/80 backdrop-blur-2xl border-t border-black/[0.04] shadow-[0_-4px_25px_rgba(0,0,0,0.03)]">
      <div className="max-w-md mx-auto grid grid-cols-3 h-16 items-center px-4">
        {/* Lists Tab */}
        <button
          onClick={() => onSelectTab('lists')}
          className={`flex flex-col items-center justify-center h-full active:scale-95 transition-all ${
            isListsActive && !isShoppingMode
              ? 'text-[#007AFF]'
              : isShoppingMode
              ? 'text-[#007AFF] font-bold'
              : 'text-stone-400 hover:text-stone-700'
          }`}
          aria-label={t.tabLists}
        >
          <div className="p-1 rounded-full relative">
            <ShoppingBag className="w-5 h-5 stroke-[2.2]" />
            {isShoppingMode && (
              <span className="absolute top-1 right-0 w-2 h-2 rounded-full bg-[#007AFF] animate-ping" />
            )}
          </div>
          <span className="text-[10px] font-semibold tracking-tight mt-0.5">
            {isShoppingMode ? (lang === 'de' ? 'Zur Liste' : 'To List') : t.tabLists}
          </span>
        </button>

        {/* Activity Tab */}
        <button
          onClick={() => onSelectTab('activity')}
          className={`flex flex-col items-center justify-center h-full active:scale-95 transition-all ${
            activeTab === 'activity' && !isShoppingMode
              ? 'text-[#007AFF]'
              : 'text-stone-400 hover:text-stone-700'
          }`}
          aria-label={t.tabActivity}
        >
          <div className="p-1 rounded-full">
            <Bell className="w-5 h-5 stroke-[2.2]" />
          </div>
          <span className="text-[10px] font-semibold tracking-tight mt-0.5">
            {t.tabActivity}
          </span>
        </button>

        {/* Fridge QR Tab */}
        <button
          onClick={() => onSelectTab('fridge')}
          className="flex flex-col items-center justify-center h-full active:scale-95 transition-all text-stone-400 hover:text-stone-700"
          aria-label={t.tabFridge}
        >
          <div className="p-1 rounded-full">
            <QrCode className="w-5 h-5 stroke-[2.2]" />
          </div>
          <span className="text-[10px] font-semibold tracking-tight mt-0.5">
            {t.tabFridge}
          </span>
        </button>
      </div>
    </nav>
  );
};
