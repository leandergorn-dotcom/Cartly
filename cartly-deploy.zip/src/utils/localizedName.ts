import { Language } from '../types';

export const FUN_NICKNAMES_DE = [
  'Naschkatze',
  'Avocado-Fan',
  'Käseliebhaber',
  'Pasta-Chef',
  'Gourmet-Bär',
  'Müslifreund',
  'Zimtstern',
  'Snack-Held',
  'Beerenpflücker',
  'Kaffee-Guru',
];

export const FUN_NICKNAMES_EN = [
  'Snack Champion',
  'Avocado Fan',
  'Cheese Lover',
  'Pasta Chef',
  'Gourmet Bear',
  'Cookie Captain',
  'Berry Picker',
  'Coffee Guru',
  'Pantry Master',
  'Chef de Cuisine',
];

export function getRandomNickname(lang: Language = 'de'): string {
  const pool = lang === 'de' ? FUN_NICKNAMES_DE : FUN_NICKNAMES_EN;
  const index = Math.floor(Math.random() * pool.length);
  return pool[index];
}

export function getLocalizedHouseholdName(name: string, lang: Language): string {
  if (!name) return '';

  if (lang === 'de') {
    if (name === 'The Miller Family') return 'Familie Miller';
    if (name.startsWith('The ') && name.endsWith(' Family')) {
      const core = name.slice(4, -7).trim();
      return `Familie ${core}`;
    }
    return name;
  } else {
    if (name === 'Familie Miller') return 'The Miller Family';
    if (name === 'Familie Kuku') return 'The Kuku Family';
    if (name.startsWith('Familie ')) {
      const core = name.slice(8).trim();
      return `The ${core} Family`;
    }
    return name;
  }
}
