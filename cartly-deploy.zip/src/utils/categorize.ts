import { CategoryId } from '../types';

const CATEGORY_KEYWORDS: Record<CategoryId, string[]> = {
  dairy: [
    'milch', 'käse', 'butter', 'joghurt', 'sahne', 'quark', 'feta', 'mozzarella',
    'gouda', 'cheddar', 'parmesan', 'frischkäse', 'schmand', 'crème fraîche',
    'eier', 'ei', 'pudding', 'skyr', 'hafermilch', 'mandelmilch', 'sojamilch',
    'milk', 'cheese', 'yogurt', 'butter', 'cream', 'eggs', 'egg', 'sour cream'
  ],
  produce: [
    'apfel', 'äpfel', 'banane', 'bananen', 'tomate', 'tomaten', 'gurke', 'gurken',
    'salat', 'kartoffel', 'kartoffeln', 'karotte', 'karotten', 'möhre', 'möhren',
    'zwiebel', 'zwiebeln', 'knoblauch', 'brokkoli', 'paprika', 'spinat', 'avocado',
    'erdbeeren', 'heidelbeeren', 'himbeeren', 'zitrone', 'zitronen', 'orange', 'orangen',
    'mandarine', 'weintrauben', 'trauben', 'zucchini', 'champignons', 'pilze', 'kohl',
    'ingwer', 'lauch', 'radieschen', 'ananas', 'mango', 'kiwi', 'birne', 'birnen',
    'apple', 'apples', 'banana', 'bananas', 'tomato', 'tomatoes', 'cucumber',
    'potato', 'potatoes', 'carrot', 'carrots', 'onion', 'onions', 'garlic', 'pepper',
    'spinach', 'strawberry', 'berries', 'lemon', 'mushrooms', 'fruit', 'vegetable'
  ],
  bakery: [
    'brot', 'brötchen', 'baguette', 'croissant', 'toast', 'brezel', 'semmel',
    'kuchen', 'muffin', 'waffeln', 'bagel', 'pita', 'fladenbrot', 'ciabatta',
    'bread', 'bun', 'buns', 'roll', 'rolls', 'bagels', 'bakery'
  ],
  meat: [
    'fleisch', 'hähnchen', 'huhn', 'rind', 'rinderhack', 'schwein', 'hack',
    'hackfleisch', 'lachs', 'fisch', 'thunfisch', 'steak', 'wurst', 'schinken',
    'salami', 'speck', 'bacon', 'garnelen', 'shrimp', 'forelle',
    'chicken', 'beef', 'pork', 'meat', 'salmon', 'fish', 'tuna', 'sausage', 'ham'
  ],
  pantry: [
    'nudeln', 'pasta', 'spaghetti', 'penne', 'reis', 'mehl', 'zucker', 'salz',
    'pfeffer', 'öl', 'olivenöl', 'rapsöl', 'essig', 'tomatenmark', 'passierte tomaten',
    'kaffee', 'tee', 'haferflocken', 'müsli', 'linsen', 'bohnen', 'kichererbsen',
    'senf', 'ketchup', 'mayo', 'mayonnaise', 'sojasauce', 'brühe', 'hefe',
    'rice', 'flour', 'sugar', 'salt', 'oil', 'olive oil', 'coffee', 'tea',
    'oats', 'cereal', 'lentils', 'beans', 'sauce', 'spices'
  ],
  drinks: [
    'wasser', 'sprudel', 'mineralwasser', 'saft', 'apfelsaft', 'orangensaft',
    'cola', 'limo', 'limonade', 'bier', 'wein', 'rotwein', 'weißwein', 'sekt',
    'gin', 'rum', 'vodka', 'energy drink', 'eistee', 'sirup',
    'water', 'juice', 'soda', 'coke', 'beer', 'wine', 'beverage', 'drink'
  ],
  frozen: [
    'pizza', 'tiefkühl', 'tk', 'eis', 'eiscreme', 'ice cream', 'pommes',
    'tk-gemüse', 'tk-beeren', 'fischstäbchen', 'frozen'
  ],
  snacks: [
    'chips', 'schokolade', 'kekse', 'nüsse', 'popcorn', 'gummibärchen',
    'riegel', 'erdnüsse', 'mandeln', 'nachos', 'salzstangen', 'cracker',
    'snack', 'snacks', 'chocolate', 'cookies', 'nuts', 'sweets', 'candy'
  ],
  household: [
    'klopapier', 'toilettenpapier', 'seife', 'shampoo', 'duschgel', 'zahnpasta',
    'zahnbürste', 'spülmittel', 'spülmaschinentabs', 'tabs', 'waschmittel',
    'weichspüler', 'taschentücher', 'küchenrolle', 'zewa', 'mülltüten', 'müllbeutel',
    'alufolie', 'backpapier', 'schwamm', 'reiniger', 'deo', 'deodorant',
    'toilet paper', 'soap', 'shampoo', 'toothpaste', 'detergent', 'trash bags',
    'sponges', 'cleaning', 'household'
  ],
  other: [],
};

/**
 * Automatically predicts category from item name.
 * Falls back to 'other' (Sonstiges) if no confident match.
 */
export function autoCategorize(name: string): CategoryId {
  const normalized = name.toLowerCase().trim();
  if (!normalized) return 'other';

  // Check exact and word matches
  for (const [category, keywords] of Object.entries(CATEGORY_KEYWORDS) as [CategoryId, string[]][]) {
    for (const kw of keywords) {
      // Check if keyword is part of the name
      const regex = new RegExp(`\\b${kw}\\b|${kw}`, 'i');
      if (regex.test(normalized)) {
        return category;
      }
    }
  }

  return 'other';
}
