export type CategoryId =
  | 'produce'
  | 'dairy'
  | 'bakery'
  | 'meat'
  | 'pantry'
  | 'drinks'
  | 'frozen'
  | 'household'
  | 'snacks'
  | 'other';

export interface CategoryInfo {
  id: CategoryId;
  nameDe: string;
  nameEn: string;
  emoji: string;
  badgeBg: string;
  badgeText: string;
}

export interface GroceryItem {
  id: string;
  householdId: string;
  name: string;
  category: CategoryId;
  quantity: string; // e.g. "1x", "2x", "200g", "1 kg", "2 cartons"
  note?: string; // e.g. "z. B. aus welchem Laden oder welche Marke"
  tag?: string; // e.g. "Sarah", "Oatly", "Organic", "0% Fat", "Sweet & crisp"
  checked: boolean; // true = Schon im Wagen (completed/in cart)
  checkedAt?: number;
  addedBy: string; // Member name
  addedAt: number;
}

export interface Member {
  id: string;
  name: string;
  color: string;
  isOnline: boolean;
  lastActive: number;
}

export interface Household {
  id: string; // 6-digit code e.g. "MLR-842" or "KUK-123"
  name: string; // e.g. "The Miller Family" or "Familie Kuku"
  createdAt: number;
  members: Member[];
}

export interface ActivityLog {
  id: string;
  householdId: string;
  type: 'add' | 'check' | 'uncheck' | 'delete' | 'join';
  itemName?: string;
  memberName: string;
  timestamp: number;
}

export type Language = 'de' | 'en';
