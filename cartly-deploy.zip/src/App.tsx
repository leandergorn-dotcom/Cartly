/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useHouseholdSync } from './hooks/useHouseholdSync';
import { OnboardingView } from './components/OnboardingView';
import { MainListView } from './components/MainListView';
import { ShoppingModeView } from './components/ShoppingModeView';
import { ScannerModal } from './components/ScannerModal';
import { AddItemModal } from './components/AddItemModal';
import { FridgeQrModal } from './components/FridgeQrModal';
import { ActivityView } from './components/ActivityView';
import { AppHeader } from './components/AppHeader';
import { BottomNavBar } from './components/BottomNavBar';
import { Language, useTranslation } from './data/translations';
import { GroceryItem } from './types';
import { getRandomNickname } from './utils/localizedName';
import { WifiOff, Plus } from 'lucide-react';

export default function App() {
  // Read persisted household ID from URL query or localStorage
  const [householdId, setHouseholdId] = useState<string | null>(() => {
    const params = new URLSearchParams(window.location.search);
    const codeParam = params.get('code');
    if (codeParam) return codeParam.toUpperCase().trim();
    return localStorage.getItem('cartly_household_id') || null;
  });

  const [memberName, setMemberName] = useState<string>(() => {
    return localStorage.getItem('cartly_member_name') || '';
  });

  const [lang, setLang] = useState<Language>(() => {
    const saved = localStorage.getItem('cartly_lang');
    return saved === 'en' ? 'en' : 'de';
  });

  const t = useTranslation(lang);

  // View States
  const [activeTab, setActiveTab] = useState<'lists' | 'activity' | 'fridge'>('lists');
  const [isShoppingMode, setIsShoppingMode] = useState<boolean>(false);
  const [isScannerOpen, setIsScannerOpen] = useState<boolean>(false);
  const [isAddItemOpen, setIsAddItemOpen] = useState<boolean>(false);
  const [isFridgeQrOpen, setIsFridgeQrOpen] = useState<boolean>(false);
  const [itemToEdit, setItemToEdit] = useState<GroceryItem | null>(null);

  // Sync hook with WebSocket & offline caching
  const {
    household,
    items,
    activities,
    members,
    activeTypers,
    isConnected,
    isLoading,
    addItem,
    toggleItem,
    deleteItem,
    updateItem,
    resetShopping,
    clearCompleted,
    notifyTyping,
  } = useHouseholdSync({
    householdId,
    currentMemberName: memberName,
  });

  // Save language preference
  const toggleLanguage = () => {
    setLang((prev: Language) => {
      const next: Language = prev === 'de' ? 'en' : 'de';
      localStorage.setItem('cartly_lang', next);
      return next;
    });
  };

  // Join existing household
  const handleJoin = async (code: string, name: string) => {
    const cleanCode = code.toUpperCase().trim();
    const finalName = name.trim() || 'Familienmitglied';

    const res = await fetch(`/api/households/${cleanCode}/join`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ memberName: finalName }),
    });

    if (!res.ok) {
      throw new Error(lang === 'de' ? 'Haushalt mit diesem Code wurde nicht gefunden.' : 'Household not found with this code.');
    }

    setHouseholdId(cleanCode);
    setMemberName(finalName);
    localStorage.setItem('cartly_household_id', cleanCode);
    localStorage.setItem('cartly_member_name', finalName);

    // Update URL clean without reload
    const url = new URL(window.location.href);
    url.searchParams.set('code', cleanCode);
    window.history.replaceState({}, '', url.toString());
  };

  // Handle URL code auto-join with nickname if needed
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const codeParam = params.get('code');

    if (codeParam && !localStorage.getItem('cartly_member_name')) {
      const autoName = getRandomNickname(lang);

      handleJoin(codeParam, autoName).catch((err) => {
        console.error('URL auto-join failed:', err);
      });
    }
  }, []);

  // Create new household
  const handleCreate = async (hName: string, name: string) => {
    const finalMemberName = name.trim() || 'Admin';

    const res = await fetch('/api/households', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: hName.trim(),
        memberName: finalMemberName,
      }),
    });

    if (!res.ok) {
      throw new Error(lang === 'de' ? 'Fehler beim Erstellen des Haushalts.' : 'Failed to create household.');
    }

    const data = await res.json();
    const newCode = data.household.id;

    setHouseholdId(newCode);
    setMemberName(finalMemberName);
    localStorage.setItem('cartly_household_id', newCode);
    localStorage.setItem('cartly_member_name', finalMemberName);

    const url = new URL(window.location.href);
    url.searchParams.set('code', newCode);
    window.history.replaceState({}, '', url.toString());
  };

  // QR Code scanned successfully
  const handleScanSuccess = async (code: string) => {
    try {
      await handleJoin(code, memberName || 'Scan-Gast');
    } catch (err: any) {
      alert(err.message || 'Konnte dem Haushalt per QR-Code nicht beitreten.');
    }
  };

  // Switch household
  const handleSwitchHousehold = () => {
    setHouseholdId(null);
    localStorage.removeItem('cartly_household_id');
    const url = new URL(window.location.href);
    url.searchParams.delete('code');
    window.history.replaceState({}, '', url.toString());
  };

  // If no household is selected, show Onboarding Gate (Image 1)
  if (!householdId || !household) {
    return (
      <>
        <OnboardingView
          onJoin={handleJoin}
          onCreate={handleCreate}
          onOpenScanner={() => setIsScannerOpen(true)}
          lang={lang}
          onToggleLang={toggleLanguage}
        />
        <ScannerModal
          isOpen={isScannerOpen}
          onClose={() => setIsScannerOpen(false)}
          onScan={handleScanSuccess}
          lang={lang}
        />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8F7F4] text-stone-900 font-sans selection:bg-blue-100 flex flex-col justify-between relative">
      {/* Offline / Reconnecting Banner */}
      {!isConnected && (
        <div className="bg-amber-500 text-white text-xs px-4 py-1.5 text-center font-medium flex items-center justify-center gap-2 sticky top-0 z-50">
          <WifiOff className="w-3.5 h-3.5" />
          <span>{t.offlineNotice}</span>
        </div>
      )}

      {/* Persistent App Header with Household menu & Language switch button */}
      <AppHeader
        household={household}
        lang={lang}
        onToggleLang={toggleLanguage}
        onOpenFridgeQr={() => setIsFridgeQrOpen(true)}
        onSwitchHousehold={handleSwitchHousehold}
        isShoppingMode={isShoppingMode}
      />

      {/* Main View Body */}
      <div className="flex-1 w-full">
        {isShoppingMode ? (
          <ShoppingModeView
            household={household}
            items={items}
            onToggleItem={toggleItem}
            onFinish={() => setIsShoppingMode(false)}
            onClearCompleted={clearCompleted}
            onResetShopping={resetShopping}
            lang={lang}
          />
        ) : activeTab === 'activity' ? (
          <ActivityView
            household={household}
            activities={activities}
            lang={lang}
          />
        ) : (
          <MainListView
            household={household}
            items={items}
            onToggleItem={toggleItem}
            onDeleteItem={deleteItem}
            onClearCompleted={clearCompleted}
            onEditItem={(item) => {
              setItemToEdit(item);
              setIsAddItemOpen(true);
            }}
            onOpenAddItem={() => {
              setItemToEdit(null);
              setIsAddItemOpen(true);
            }}
            onOpenShoppingMode={() => setIsShoppingMode(true)}
            lang={lang}
          />
        )}
      </div>

      {/* Persistent Bottom Floating Action Button (+) for Adding Items */}
      {activeTab === 'lists' && !isShoppingMode && (
        <div className="fixed bottom-20 left-0 right-0 pointer-events-none z-30">
          <div className="max-w-md mx-auto px-4 flex justify-end">
            <button
              onClick={() => {
                setItemToEdit(null);
                setIsAddItemOpen(true);
              }}
              className="pointer-events-auto w-14 h-14 rounded-full bg-[#007AFF] hover:bg-blue-600 text-white shadow-[0_8px_25px_rgba(0,122,255,0.35)] flex items-center justify-center active:scale-90 transition-all"
              aria-label={t.addItem}
            >
              <Plus className="w-6 h-6 stroke-[2.6]" />
            </button>
          </div>
        </div>
      )}

      {/* Persistent Bottom Navigation Bar */}
      <BottomNavBar
        activeTab={isShoppingMode ? 'shopping' : activeTab}
        isShoppingMode={isShoppingMode}
        onSelectTab={(tab) => {
          if (tab === 'fridge') {
            setIsFridgeQrOpen(true);
          } else {
            setIsShoppingMode(false);
            setActiveTab(tab);
          }
        }}
        lang={lang}
      />

      {/* Modals */}
      <ScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onScan={handleScanSuccess}
        lang={lang}
      />

      <AddItemModal
        isOpen={isAddItemOpen}
        onClose={() => {
          setIsAddItemOpen(false);
          setItemToEdit(null);
        }}
        onAdd={addItem}
        itemToEdit={itemToEdit}
        onUpdate={updateItem}
        onDelete={deleteItem}
        lang={lang}
        onTyping={notifyTyping}
      />

      <FridgeQrModal
        isOpen={isFridgeQrOpen}
        onClose={() => setIsFridgeQrOpen(false)}
        household={household}
        lang={lang}
      />
    </div>
  );
}
