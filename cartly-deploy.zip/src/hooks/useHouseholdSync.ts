import { useState, useEffect, useRef, useCallback } from 'react';
import { Household, GroceryItem, ActivityLog, Member, CategoryId } from '../types';

interface UseHouseholdSyncProps {
  householdId: string | null;
  currentMemberName: string;
}

export function useHouseholdSync({ householdId, currentMemberName }: UseHouseholdSyncProps) {
  const [household, setHousehold] = useState<Household | null>(null);
  const [items, setItems] = useState<GroceryItem[]>([]);
  const [activities, setActivities] = useState<ActivityLog[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [activeTypers, setActiveTypers] = useState<string[]>([]);
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const socketRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<any>(null);
  const typingTimeoutRef = useRef<any>(null);

  // Load initial data via REST API
  const fetchHousehold = useCallback(async (code: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/households/${code}`);
      if (!res.ok) {
        throw new Error('Haushalt nicht gefunden');
      }
      const data = await res.json();
      setHousehold(data.household);
      setItems(data.items || []);
      setActivities(data.activities || []);
      setMembers(data.household.members || []);
      
      // Save to localStorage as backup
      localStorage.setItem(`cartly_cached_${code}`, JSON.stringify(data));
    } catch (err: any) {
      console.warn('Failed to fetch from server, checking local cache:', err);
      const cached = localStorage.getItem(`cartly_cached_${code}`);
      if (cached) {
        try {
          const parsed = JSON.parse(cached);
          setHousehold(parsed.household);
          setItems(parsed.items || []);
          setActivities(parsed.activities || []);
          setMembers(parsed.household.members || []);
        } catch {
          setError(err.message || 'Fehler beim Laden');
        }
      } else {
        setError(err.message || 'Fehler beim Laden');
      }
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Setup WebSocket connection
  useEffect(() => {
    if (!householdId) {
      setHousehold(null);
      setItems([]);
      return;
    }

    fetchHousehold(householdId);
    let disposed = false;

    function connectWs() {
      if (socketRef.current?.readyState === WebSocket.OPEN) {
        socketRef.current.close();
      }

      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}`;
      const ws = new WebSocket(wsUrl);
      socketRef.current = ws;

      ws.onopen = () => {
        setIsConnected(true);
        ws.send(
          JSON.stringify({
            type: 'subscribe',
            householdId,
            member: {
              name: currentMemberName || 'Familienmitglied',
              id: `m-${currentMemberName}`,
            },
          })
        );
      };

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          if (msg.type === 'init_sync') {
            if (msg.household) setHousehold(msg.household);
            if (msg.items) setItems(msg.items);
            if (msg.activities) setActivities(msg.activities);
            if (msg.household?.members) setMembers(msg.household.members);
          } else if (msg.type === 'item_added') {
            setItems((prev) => {
              if (prev.some((item) => item.id === msg.item.id)) return prev;
              return [msg.item, ...prev];
            });
            if (msg.activity) {
              setActivities((prev) => [msg.activity, ...prev]);
            }
          } else if (msg.type === 'item_updated') {
            setItems((prev) =>
              prev.map((item) => (item.id === msg.item.id ? msg.item : item))
            );
            if (msg.activity) {
              setActivities((prev) => [msg.activity, ...prev]);
            }
          } else if (msg.type === 'item_deleted') {
            setItems((prev) => prev.filter((item) => item.id !== msg.itemId));
            if (msg.activity) {
              setActivities((prev) => [msg.activity, ...prev]);
            }
          } else if (msg.type === 'presence_updated') {
            if (msg.members) setMembers(msg.members);
            if (msg.activity) {
              setActivities((prev) => [msg.activity, ...prev]);
            }
          } else if (msg.type === 'shopping_reset') {
            if (msg.items) setItems(msg.items);
          } else if (msg.type === 'items_cleared') {
            if (msg.items) setItems(msg.items);
          } else if (msg.type === 'member_typing') {
            if (msg.status) {
              setActiveTypers((prev) =>
                prev.includes(msg.memberName) ? prev : [...prev, msg.memberName]
              );
            } else {
              setActiveTypers((prev) => prev.filter((m) => m !== msg.memberName));
            }
          }
        } catch (e) {
          console.error('Error handling WebSocket message', e);
        }
      };

      ws.onclose = () => {
        // Alte oder aufgeräumte Verbindungen dürfen keine Neuverbindung auslösen (sonst entstehen Doppel-Sockets)
        if (disposed || socketRef.current !== ws) return;
        setIsConnected(false);
        // Automatic reconnection every 3 seconds
        reconnectTimeoutRef.current = setTimeout(() => {
          if (householdId) connectWs();
        }, 3000);
      };

      ws.onerror = (err) => {
        console.warn('WebSocket encountered error', err);
        ws.close();
      };
    }

    connectWs();

    // Nach dem Aufwachen des Handys: Stand sofort neu laden und ggf. neu verbinden
    const onVisible = () => {
      if (document.visibilityState !== 'visible' || disposed) return;
      fetchHousehold(householdId);
      if (socketRef.current?.readyState !== WebSocket.OPEN) {
        clearTimeout(reconnectTimeoutRef.current);
        connectWs();
      }
    };
    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('online', onVisible);

    return () => {
      disposed = true;
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('online', onVisible);
      clearTimeout(reconnectTimeoutRef.current);
      if (socketRef.current) {
        socketRef.current.close();
      }
    };
  }, [householdId, currentMemberName, fetchHousehold]);

  // Mutations with optimistic updates
  const addItem = async (data: {
    name: string;
    category: CategoryId;
    quantity: string;
    note?: string;
    tag?: string;
  }) => {
    if (!householdId) return;

    const tempId = `temp-${Date.now()}`;
    const optimisticItem: GroceryItem = {
      id: tempId,
      householdId,
      name: data.name,
      category: data.category,
      quantity: data.quantity || '1x',
      note: data.note,
      tag: data.tag,
      checked: false,
      addedBy: currentMemberName || 'Du',
      addedAt: Date.now(),
    };

    setItems((prev) => [optimisticItem, ...prev]);

    try {
      const res = await fetch(`/api/households/${householdId}/items`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...data,
          addedBy: currentMemberName || 'Du',
        }),
      });
      if (!res.ok) throw new Error('Fehler beim Hinzufügen');
      const result = await res.json();
      // Replace optimistic item with server item
      setItems((prev) =>
        prev.map((item) => (item.id === tempId ? result.item : item))
      );
    } catch (err) {
      console.error(err);
      // Revert if error
      setItems((prev) => prev.filter((item) => item.id !== tempId));
    }
  };

  const toggleItem = async (itemId: string, checked: boolean) => {
    if (!householdId) return;

    setItems((prev) =>
      prev.map((item) =>
        item.id === itemId
          ? { ...item, checked, checkedAt: checked ? Date.now() : undefined }
          : item
      )
    );

    try {
      await fetch(`/api/households/${householdId}/items/${itemId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ checked, memberName: currentMemberName || 'Du' }),
      });
    } catch (err) {
      console.error('Failed to toggle item', err);
    }
  };

  const deleteItem = async (itemId: string) => {
    if (!householdId) return;

    const previousItems = items;
    setItems((prev) => prev.filter((item) => item.id !== itemId));

    try {
      const res = await fetch(
        `/api/households/${householdId}/items/${itemId}?memberName=${encodeURIComponent(
          currentMemberName || 'Du'
        )}`,
        { method: 'DELETE' }
      );
      if (!res.ok) throw new Error('Fehler beim Löschen');
    } catch (err) {
      console.error('Failed to delete item', err);
      setItems(previousItems);
    }
  };

  const updateItem = async (itemId: string, fields: Partial<GroceryItem>) => {
    if (!householdId) return;

    setItems((prev) =>
      prev.map((item) => (item.id === itemId ? { ...item, ...fields } : item))
    );

    try {
      await fetch(`/api/households/${householdId}/items/${itemId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...fields, memberName: currentMemberName || 'Du' }),
      });
    } catch (err) {
      console.error('Failed to update item', err);
    }
  };

  const resetShopping = async () => {
    if (!householdId) return;
    try {
      await fetch(`/api/households/${householdId}/reset-shopping`, {
        method: 'POST',
      });
      setItems((prev) => prev.map((item) => ({ ...item, checked: false })));
    } catch (err) {
      console.error('Failed to reset shopping', err);
    }
  };

  const clearCompleted = async () => {
    if (!householdId) return;
    try {
      await fetch(`/api/households/${householdId}/clear-completed`, {
        method: 'POST',
      });
      setItems((prev) => prev.filter((i) => !i.checked));
    } catch (err) {
      console.error('Failed to clear completed items', err);
    }
  };

  const notifyTyping = (isTyping: boolean) => {
    if (socketRef.current?.readyState === WebSocket.OPEN) {
      socketRef.current.send(
        JSON.stringify({
          type: 'typing',
          memberName: currentMemberName || 'Jemand',
          status: isTyping,
        })
      );
    }
    clearTimeout(typingTimeoutRef.current);
    if (isTyping) {
      typingTimeoutRef.current = setTimeout(() => notifyTyping(false), 2500);
    }
  };

  return {
    household,
    items,
    activities,
    members,
    activeTypers,
    isConnected,
    isLoading,
    error,
    addItem,
    toggleItem,
    deleteItem,
    updateItem,
    resetShopping,
    clearCompleted,
    notifyTyping,
    refetch: () => householdId && fetchHousehold(householdId),
  };
}
